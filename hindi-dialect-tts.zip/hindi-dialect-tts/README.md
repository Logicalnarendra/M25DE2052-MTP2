# Dialect-Aware Synthesis and Bias-Corrected Evaluation for Hindi TTS

Application code for two linked problems raised in *Evaluating user preferences in Hindi
Text-to-Speech* (B. Gupta, MeitY):

1. **Dialect-aware synthesis** – make a standard Hindi TTS voice speak with Haryanvi,
   Chhattisgarhi, Awadhi, Braj, Bihari or Khadi Boli pronunciation, using the paper's
   character rules (Table 4) and word dictionaries, delivered as SSML/PLS or plain text.
2. **Bias-corrected evaluation** – run blind MOS/DMOS listening tests, record evaluator
   dialect metadata, and correct scores for dialect-driven rater bias before reporting.

Synthesis backend: **AI4Bharat Indic-TTS** (FastPitch + HiFi-GAN, Hindi male/female). A
deterministic `mock` engine is included so everything else, tests included, runs without
model downloads.

```
app/
  dialects/      devanagari.py · rules.py (Table 4) · lexicon.py · transformer.py · ssml.py (SSML + PLS)
  tts/           base.py · indic_tts.py (AI4Bharat) · mock.py
  evaluation/    mos.py · bias.py (5 corrections) · weights.py · stats.py · report.py · simulate.py
  replication/   paper.py (published numbers + consistency checks)
  models.py db.py services.py main.py (FastAPI) static/listening_test.html
data/            lexicon/*.csv · sentences_hi.csv · paper/table5_*.csv
scripts/         manage.py · download_indic_tts.py · replicate_paper.py · power_analysis.py
tests/           ~165 pytest cases (rules, lexicon, SSML, TTS, evaluation, replication, API)
docs/            REPLICATION.md · DATASETS.md
```

## How it works

```
Hindi text ──► DialectTransformer(dialect, mode, level) ──► TransformResult (+ change spans)
                 mode: standard | char | lexicon | combined        │
                                                                  ├─► SSML  <sub alias="हात">हाथ</sub>   (SSML engines)
                                                                  ├─► PLS   /lexicon/haryanvi.pls
                                                                  └─► flatten_ssml ─► Indic-TTS (plain text + pauses) ─► WAV
WAV samples ──► blind listening test (/)  ──► ratings + evaluator dialect ──► correction ──► MOS ± CI, weighted MOS, paired tests
```

* `char` = the paper's "character variations" condition, `lexicon` = "word variations using
  dictionary", `combined` = dictionary first, rules for unknown words.
* Rule `level`: `conservative` (regular sound changes such as Haryanvi श→स, final थ→त) or `full`
  (every Table-4 pattern, some of which only hold for part of the vocabulary).

### Bias corrections (`/results?correction=…`)

| name | what it does | when to use |
|---|---|---|
| `none` | raw scores | reporting alongside corrected values |
| `paper_regression` | paper Sec. 6.1: per dialect, `y_khadi = a·x_dialect + b` on shared items | replication only (compresses the scale when a < 1) |
| `offset` | adds each dialect's mean gap to the reference on shared items | simple, transparent baseline |
| `zscore` | per-rater standardisation, rescaled to reference group | strong scale-use differences |
| `mixed` | `score ~ system + dialect + (1 \| rater)`; removes dialect effect and rater leniency | **recommended default**, handles unbalanced designs |

Weighting (`weighting=equal|population|inverse_var`) combines dialect-group means so that a
large rater group does not dominate the system score.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env                       # SQLite by default

# without models (mock audio) – everything works end to end
TTS_ENGINE=mock python scripts/manage.py init
TTS_ENGINE=mock python scripts/manage.py generate
TTS_ENGINE=mock uvicorn app.main:app --reload     # http://127.0.0.1:8000  (API docs: /docs)
```

### With AI4Bharat Indic-TTS

```bash
pip install -r requirements-tts.txt        # Coqui TTS runtime (Python 3.10/3.11 venv)
python scripts/download_indic_tts.py       # fetches hi.zip, patches speaker paths
python scripts/manage.py init --speakers female,male
python scripts/manage.py generate          # 20 sentences × 5 systems × 2 voices
uvicorn app.main:app
```

Indic-TTS has no SSML support, so the app sends it the dialect spelling as text (the SSML is
still stored with every sample and can be sent to an SSML engine instead).

### API examples

```bash
curl -s localhost:8000/transform -H 'content-type: application/json' \
  -d '{"text":"राजा ने अपने हाथ से खाना खाया।","dialect":"haryanvi","mode":"combined"}'
curl -s localhost:8000/synthesize -H 'content-type: application/json' \
  -d '{"text":"सीता कचहरी गई।","dialect":"chhattisgarhi","speaker":"male"}' -o out.wav
curl -s localhost:8000/lexicon/haryanvi.pls
curl -s 'localhost:8000/results?correction=mixed&weighting=equal'
```

Admin endpoints (`/admin/seed`, `/admin/generate`, `/admin/natural/{sentence_id}` for natural
reference WAVs used in DMOS) need the `X-Admin-Token` header when `ADMIN_TOKEN` is set.

## Database

SQLite (`data/app.db`) by default, no setup. For multi-site listening tests switch to
PostgreSQL by changing one variable – the SQLAlchemy models are identical:

```bash
docker compose up -d db
export DATABASE_URL=postgresql+psycopg://tts:tts@localhost:5432/hindi_tts
python scripts/manage.py init
```

Tables: `dialects`, `evaluators` (dialect, native place, state, age, gender, education),
`tts_systems` (engine, voice, mode, target dialect, natural flag), `sentences`,
`audio_samples` (rendered text + SSML), `ratings` (MOS/DMOS, unique per evaluator/sample/test,
score 1–5 check), `lexicon_entries`.

Try the analysis without running a listening test:
`python scripts/manage.py import-ratings data/sample_ratings.csv && python scripts/manage.py results --correction mixed --weighting equal`
(simulated ratings, Haryanvi raters planted +0.4 lenient).

Bring existing score sheets in with
`python scripts/manage.py import-ratings sheet.csv` (columns `rater_id, rater_dialect, system,
sentence_id, score[, test_type]`). Public speech/text datasets that fit this project are listed in
[docs/DATASETS.md](docs/DATASETS.md).

## Running the tests

```bash
pytest                       # ~165 tests in a few seconds; mock engine + temporary SQLite
pytest tests/test_rules.py -v                 # one module
pytest -k "replication or bias"               # by keyword
pytest -m indic              # real Indic-TTS smoke test (after downloading checkpoints)
```

| file | covers |
|---|---|
| `test_rules.py` | all 57 Table-4 examples, level nesting, edge cases (virama, nukta) |
| `test_lexicon.py` | CSV loading, NFC-insensitive lookup, provenance flags |
| `test_transformer_ssml.py` | the 4 modes, offsets, punctuation, SSML/PLS validity, SSML flattening, entity rejection |
| `test_tts.py` | mock engine, pauses from SSML, WAV round trip, helpful Indic-TTS errors |
| `test_evaluation.py` | CI maths vs SciPy, planted-bias recovery for every correction, weights, Holm, JSON safety |
| `test_replication.py` | Table-5 means, significance, published regression consistency |
| `test_api.py` | full flow: seed → generate → register → blind rating → corrected results; DMOS reference |

## Paper replication

`python scripts/replicate_paper.py` → `reports/replication_report.md` (+ figures).
The plan for a full replication with new listening data is in
[docs/REPLICATION.md](docs/REPLICATION.md).

## Caveats

* Lexicon rows marked `community_seed` are unverified common forms – check them with native
  speakers before use. `paper_table4` rows are transcribed from the paper.
* `full` rule level overgenerates for some words; use `combined` mode with a growing lexicon in production.
* Bundeli has no published patterns yet (lexicon-only placeholder).
