"""Database schema.

    dialects ─┬─< evaluators ─< ratings >─ audio_samples >─┬─ sentences
              ├─< lexicon_entries                           └─ tts_systems
              └─< tts_systems (target dialect, nullable)

Evaluator metadata (native place, state, age, education) follows the paper's
recommendation to record evaluator background so scores can be analysed and
corrected per dialect region.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (Boolean, CheckConstraint, DateTime, Float, ForeignKey, Integer, String,
                        Text, UniqueConstraint)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Dialect(Base):
    __tablename__ = "dialects"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(64))
    hindi_name: Mapped[str] = mapped_column(String(64), default="")
    region: Mapped[str] = mapped_column(String(200), default="")
    is_reference: Mapped[bool] = mapped_column(Boolean, default=False)


class Evaluator(Base):
    __tablename__ = "evaluators"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    dialect_id: Mapped[int] = mapped_column(ForeignKey("dialects.id"))
    native_place: Mapped[str] = mapped_column(String(120), default="")
    state: Mapped[str] = mapped_column(String(64), default="")
    age: Mapped[int | None] = mapped_column(Integer, nullable=True)
    gender: Mapped[str] = mapped_column(String(16), default="")
    education: Mapped[str] = mapped_column(String(120), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    dialect: Mapped[Dialect] = relationship()
    ratings: Mapped[list["Rating"]] = relationship(back_populates="evaluator")


class TTSSystem(Base):
    """A synthesis condition: engine + voice + dialect mode (+ target dialect)."""
    __tablename__ = "tts_systems"
    __table_args__ = (UniqueConstraint("name"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    engine: Mapped[str] = mapped_column(String(32))
    speaker: Mapped[str] = mapped_column(String(32), default="female")
    mode: Mapped[str] = mapped_column(String(16), default="standard")   # standard|char|lexicon|combined
    dialect_id: Mapped[int | None] = mapped_column(ForeignKey("dialects.id"), nullable=True)
    is_natural: Mapped[bool] = mapped_column(Boolean, default=False)    # human recordings (DMOS reference)
    dialect: Mapped[Dialect | None] = relationship()


class Sentence(Base):
    __tablename__ = "sentences"
    id: Mapped[int] = mapped_column(primary_key=True)
    text_hi: Mapped[str] = mapped_column(Text)
    tags: Mapped[str] = mapped_column(String(200), default="")


class AudioSample(Base):
    __tablename__ = "audio_samples"
    __table_args__ = (UniqueConstraint("sentence_id", "system_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    sentence_id: Mapped[int] = mapped_column(ForeignKey("sentences.id"))
    system_id: Mapped[int] = mapped_column(ForeignKey("tts_systems.id"))
    path: Mapped[str] = mapped_column(String(400))
    rendered_text: Mapped[str] = mapped_column(Text, default="")
    ssml: Mapped[str] = mapped_column(Text, default="")
    duration_s: Mapped[float] = mapped_column(Float, default=0.0)
    sentence: Mapped[Sentence] = relationship()
    system: Mapped[TTSSystem] = relationship()


class Rating(Base):
    __tablename__ = "ratings"
    __table_args__ = (
        UniqueConstraint("evaluator_id", "sample_id", "test_type"),
        CheckConstraint("score >= 1 AND score <= 5", name="score_range"),
    )
    id: Mapped[int] = mapped_column(primary_key=True)
    evaluator_id: Mapped[int] = mapped_column(ForeignKey("evaluators.id"), index=True)
    sample_id: Mapped[int] = mapped_column(ForeignKey("audio_samples.id"), index=True)
    test_type: Mapped[str] = mapped_column(String(8))         # MOS | DMOS
    score: Mapped[float] = mapped_column(Float)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    evaluator: Mapped[Evaluator] = relationship(back_populates="ratings")
    sample: Mapped[AudioSample] = relationship()


class LexiconEntryRow(Base):
    __tablename__ = "lexicon_entries"
    __table_args__ = (UniqueConstraint("dialect_id", "hindi"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    dialect_id: Mapped[int] = mapped_column(ForeignKey("dialects.id"))
    hindi: Mapped[str] = mapped_column(String(120))
    dialect_form: Mapped[str] = mapped_column(String(120))
    pos: Mapped[str] = mapped_column(String(16), default="")
    source: Mapped[str] = mapped_column(String(64), default="")
    verified: Mapped[bool] = mapped_column(Boolean, default=False)
    dialect: Mapped[Dialect] = relationship()
