"""Devanagari helpers shared by the dialect rules.

All text is normalised to Unicode NFC before rules run. Note that NFC
*decomposes* the precomposed nukta letters (U+0958..U+095F), so ड़ is always
the two code points "ड" + "़" (U+0921 U+093C) after normalisation.
"""
from __future__ import annotations

import re
import unicodedata

NUKTA = "़"
VIRAMA = "्"
CHANDRABINDU = "ँ"
ANUSVARA = "ं"

RRA = "ड" + NUKTA    # ड़
RHA = "ढ" + NUKTA    # ढ़

# A consonant, optionally followed by a nukta.
CONSONANT = r"[क-ह]" + NUKTA + "?"
# Dependent vowel signs (matras) ा ि ी ु ू ृ ॄ ॅ ॆ े ै ॉ ॊ ो ौ
MATRA = r"[ा-ौ]"
LONG_MATRA = "[ाीूेैोौ]"   # ा ी ू े ै ो ौ
LONG_INDEPENDENT_VOWEL = "[आईऊएऐओऔ]"  # आ ई ऊ ए ऐ ओ औ

# A "word" is a run of Devanagari letters/marks. Danda (।) and double danda
# (॥) are excluded so punctuation survives untouched.
WORD_RE = re.compile(r"[ऀ-ॣ०-ॿ]+")

# Aspirated (महाप्राण) -> unaspirated (अल्पप्राण) partner, used for gemination:
# देखा -> देक्खा, भूखा -> भुक्खा (the geminate is written unaspirated + virama + aspirated).
ASPIRATE_TO_PLAIN = {
    "ख": "क", "घ": "ग", "छ": "च", "झ": "ज", "ठ": "ट",
    "ढ": "ड", "थ": "त", "ध": "द", "फ": "प", "भ": "ब",
}


def nfc(text: str) -> str:
    return unicodedata.normalize("NFC", text)


def geminate(consonant: str) -> str:
    """Return the doubled (geminated) written form of a consonant.

    >>> geminate("ज")
    'ज्ज'
    >>> geminate("ख")
    'क्ख'
    """
    if consonant.endswith(NUKTA):          # ड़ -> ड्ड (paper: गाड़ी -> गाड्डी)
        base = consonant[0]
        return base + VIRAMA + base
    plain = ASPIRATE_TO_PLAIN.get(consonant, consonant)
    return plain + VIRAMA + consonant
