"""W3C SSML 1.1 and PLS 1.0 output, plus an SSML flattener.

The paper implements dialect pronunciations through SSML. We emit:

* SSML where every changed word is wrapped in ``<sub alias="…">`` – the
  displayed text stays standard Hindi, the engine speaks the dialect form;
* a PLS lexicon (``<lexeme><grapheme/><alias/></lexeme>``) per dialect that
  SSML-capable engines can load via ``<lexicon uri="…"/>``.

AI4Bharat Indic-TTS (FastPitch + HiFi-GAN) does **not** read SSML, so
:func:`flatten_ssml` turns SSML into plain-text segments and pauses that the
engine adapter synthesises one by one and concatenates.
"""
from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from xml.sax.saxutils import escape, quoteattr

from .lexicon import Lexicon
from .transformer import TransformResult

SSML_NS = "http://www.w3.org/2001/10/synthesis"
PLS_NS = "http://www.w3.org/2005/01/pronunciation-lexicon"


def to_ssml(result: TransformResult, lang: str = "hi-IN", voice: str | None = None,
            rate: str | None = None, lexicon_uri: str | None = None,
            sentence_break_ms: int | None = 300) -> str:
    """Build SSML from a :class:`TransformResult`."""
    body: list[str] = []
    cursor = 0
    src = result.original
    for ch in result.changes:
        body.append(escape(src[cursor:ch.start]))
        body.append(f"<sub alias={quoteattr(ch.target)}>{escape(ch.source)}</sub>")
        cursor = ch.end
    body.append(escape(src[cursor:]))
    inner = "".join(body)
    if sentence_break_ms:
        inner = re.sub(r"([।?!])\s+", rf'\1<break time="{sentence_break_ms}ms"/> ', inner)
    if rate:
        inner = f"<prosody rate={quoteattr(rate)}>{inner}</prosody>"
    if voice:
        inner = f"<voice name={quoteattr(voice)}>{inner}</voice>"
    lex = f"<lexicon uri={quoteattr(lexicon_uri)}/>" if lexicon_uri else ""
    return (f'<?xml version="1.0" encoding="UTF-8"?>\n'
            f'<speak version="1.1" xmlns="{SSML_NS}" xml:lang="{lang}">{lex}{inner}</speak>')


def to_pls(lexicon: Lexicon, dialect: str, lang: str = "hi-IN") -> str:
    lexemes = []
    for e in sorted(lexicon.entries(dialect), key=lambda e: e.hindi):
        lexemes.append(
            f"  <lexeme>\n    <grapheme>{escape(e.hindi)}</grapheme>\n"
            f"    <alias>{escape(e.dialect_form)}</alias>\n  </lexeme>")
    return (f'<?xml version="1.0" encoding="UTF-8"?>\n'
            f'<lexicon version="1.0" xmlns="{PLS_NS}" alphabet="ipa" xml:lang="{lang}">\n'
            + "\n".join(lexemes) + "\n</lexicon>\n")


# --------------------------------------------------------------------------
@dataclass(frozen=True)
class Segment:
    text: str = ""
    pause_ms: int = 0
    rate: float = 1.0


_RATE_WORDS = {"x-slow": 0.5, "slow": 0.75, "medium": 1.0, "fast": 1.25, "x-fast": 1.5, "default": 1.0}
_STRENGTH_MS = {"none": 0, "x-weak": 100, "weak": 200, "medium": 400, "strong": 700, "x-strong": 1000}


def _parse_rate(value: str | None, parent: float) -> float:
    if not value:
        return parent
    value = value.strip()
    if value in _RATE_WORDS:
        return _RATE_WORDS[value]
    if value.endswith("%"):
        return parent * float(value[:-1]) / 100.0
    return parent * float(value)


def _parse_time(value: str) -> int:
    value = value.strip()
    if value.endswith("ms"):
        return int(float(value[:-2]))
    if value.endswith("s"):
        return int(float(value[:-1]) * 1000)
    return int(float(value))


def flatten_ssml(ssml: str, max_chars: int = 200_000) -> list[Segment]:
    """SSML → ordered list of text/pause segments (for engines without SSML)."""
    if len(ssml) > max_chars:
        raise ValueError("SSML document too large")
    if "<!DOCTYPE" in ssml or "<!ENTITY" in ssml:
        raise ValueError("DTDs/entities are not allowed in SSML input")
    try:
        root = ET.fromstring(ssml.encode("utf-8"))
    except ET.ParseError as exc:          # ParseError is a SyntaxError, not a ValueError
        raise ValueError(f"malformed SSML: {exc}") from exc
    segs: list[Segment] = []

    def local(tag: str) -> str:
        return tag.rsplit("}", 1)[-1]

    def emit(text: str | None, rate: float) -> None:
        if not text:
            return
        if segs and segs[-1].pause_ms == 0 and segs[-1].rate == rate:
            segs[-1] = Segment(segs[-1].text + text, 0, rate)   # keep inter-word spaces
        elif text.strip():
            segs.append(Segment(text, 0, rate))

    def walk(el: ET.Element, rate: float) -> None:
        tag = local(el.tag)
        if tag == "sub":
            emit(el.get("alias", el.text or ""), rate)
        elif tag == "break":
            ms = _parse_time(el.get("time")) if el.get("time") else _STRENGTH_MS.get(el.get("strength", "medium"), 400)
            segs.append(Segment("", ms, rate))
        elif tag in ("lexicon", "metadata", "mark", "desc"):
            pass
        elif tag == "phoneme":
            emit(el.text, rate)          # alphabet not interpretable here; speak orthography
        else:
            child_rate = _parse_rate(el.get("rate"), rate) if tag == "prosody" else rate
            emit(el.text, child_rate)
            for child in el:
                walk(child, child_rate)
                emit(child.tail, child_rate)   # a child's tail belongs to the parent

    walk(root, 1.0)
    cleaned = [Segment(" ".join(s.text.split()), s.pause_ms, s.rate) for s in segs]
    return [s for s in cleaned if s.text or s.pause_ms]
