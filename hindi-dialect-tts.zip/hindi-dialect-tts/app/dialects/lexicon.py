"""Hindi → dialect word dictionary ("word variations using dictionary").

The paper built ~1,500 Chhattisgarhi and ~2,100 Haryanvi entries. This repo
ships the Table-4 examples plus a few clearly-flagged ``community_seed``
entries; grow the CSVs (or the ``lexicon_entries`` DB table) to scale up.

CSV columns: hindi, dialect_form, pos, source, verified, notes
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .devanagari import nfc
from .rules import DIALECTS

DEFAULT_LEXICON_DIR = Path(__file__).resolve().parents[2] / "data" / "lexicon"


@dataclass(frozen=True)
class LexiconEntry:
    dialect: str
    hindi: str
    dialect_form: str
    pos: str = ""
    source: str = ""
    verified: bool = False
    notes: str = ""


class Lexicon:
    def __init__(self, entries: Iterable[LexiconEntry] = ()):
        self._by_dialect: dict[str, dict[str, LexiconEntry]] = {}
        for e in entries:
            self.add(e)

    # -- construction -------------------------------------------------------
    def add(self, entry: LexiconEntry) -> None:
        if entry.dialect not in DIALECTS:
            raise KeyError(f"unknown dialect {entry.dialect!r}")
        e = LexiconEntry(
            entry.dialect, nfc(entry.hindi.strip()), nfc(entry.dialect_form.strip()),
            entry.pos, entry.source, entry.verified, entry.notes,
        )
        if not e.hindi or not e.dialect_form:
            raise ValueError(f"empty lexicon field in {entry!r}")
        self._by_dialect.setdefault(e.dialect, {})[e.hindi] = e

    @classmethod
    def from_csv(cls, path: str | Path, dialect: str | None = None) -> "Lexicon":
        lex = cls()
        lex.load_csv(path, dialect)
        return lex

    def load_csv(self, path: str | Path, dialect: str | None = None) -> None:
        path = Path(path)
        dialect = dialect or path.stem
        with path.open(encoding="utf-8", newline="") as fh:
            for row in csv.DictReader(fh):
                self.add(LexiconEntry(
                    dialect=dialect,
                    hindi=row["hindi"],
                    dialect_form=row["dialect_form"],
                    pos=row.get("pos", "") or "",
                    source=row.get("source", "") or "",
                    verified=(row.get("verified", "") or "").strip().lower() in {"yes", "true", "1"},
                    notes=row.get("notes", "") or "",
                ))

    @classmethod
    def from_dir(cls, directory: str | Path = DEFAULT_LEXICON_DIR,
                 verified_only: bool = False) -> "Lexicon":
        lex = cls()
        for csv_path in sorted(Path(directory).glob("*.csv")):
            if csv_path.stem in DIALECTS:
                lex.load_csv(csv_path)
        if verified_only:
            lex = cls(e for e in lex.entries() if e.verified)
        return lex

    # -- queries ------------------------------------------------------------
    def lookup(self, dialect: str, word: str) -> LexiconEntry | None:
        return self._by_dialect.get(dialect, {}).get(nfc(word))

    def entries(self, dialect: str | None = None) -> list[LexiconEntry]:
        if dialect:
            return list(self._by_dialect.get(dialect, {}).values())
        return [e for d in self._by_dialect.values() for e in d.values()]

    def __len__(self) -> int:
        return sum(len(d) for d in self._by_dialect.values())

    def dialects(self) -> list[str]:
        return sorted(self._by_dialect)
