"""Hindi text → dialect-aware text for synthesis.

Modes mirror the three conditions evaluated in the paper (Table 5):

* ``standard``  – unchanged Hindi ("Score: Hindi TTS system")
* ``char``      – character-level rules only ("Character variations")
* ``lexicon``   – dictionary substitution only ("Word variations using dictionary")
* ``combined``  – dictionary first, rules for out-of-vocabulary words (our extension)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from .devanagari import WORD_RE, nfc
from .lexicon import Lexicon
from .rules import DIALECTS, Level, rules_for

Mode = Literal["standard", "char", "lexicon", "combined"]
MODES: tuple[str, ...] = ("standard", "char", "lexicon", "combined")


@dataclass(frozen=True)
class Change:
    start: int          # character offsets in the *original* (NFC) text
    end: int
    source: str         # original Hindi word
    target: str         # dialect spelling sent to the TTS
    origin: str         # "lexicon" or "rule:<rule_id>[+rule:<id>...]"


@dataclass
class TransformResult:
    original: str
    text: str
    dialect: str
    mode: str
    changes: list[Change] = field(default_factory=list)

    @property
    def n_changed(self) -> int:
        return len(self.changes)


class DialectTransformer:
    def __init__(self, dialect: str, lexicon: Lexicon | None = None,
                 level: Level = "conservative"):
        if dialect not in DIALECTS:
            raise KeyError(f"unknown dialect {dialect!r}; known: {sorted(DIALECTS)}")
        self.dialect = dialect
        self.lexicon = lexicon if lexicon is not None else Lexicon()
        self.level = level
        self.rules = rules_for(dialect, level)

    def transform_word(self, word: str, mode: Mode) -> tuple[str, str | None]:
        """Return (new_word, origin) – origin is None when nothing changed."""
        if mode == "standard":
            return word, None
        if mode in ("lexicon", "combined"):
            entry = self.lexicon.lookup(self.dialect, word)
            if entry is not None:
                return entry.dialect_form, "lexicon"
            if mode == "lexicon":
                return word, None
        # char rules (mode == "char", or OOV word in "combined")
        out, fired = word, []
        for rule in self.rules:
            new = rule.apply(out)
            if new != out:
                fired.append(f"rule:{rule.id}")
                out = new
        return out, ("+".join(fired) if fired else None)

    def transform(self, text: str, mode: Mode = "combined") -> TransformResult:
        if mode not in MODES:
            raise ValueError(f"mode must be one of {MODES}")
        text = nfc(text)
        pieces: list[str] = []
        changes: list[Change] = []
        cursor = 0
        for m in WORD_RE.finditer(text):
            pieces.append(text[cursor:m.start()])
            word = m.group(0)
            new, origin = self.transform_word(word, mode)
            pieces.append(new)
            if origin and new != word:
                changes.append(Change(m.start(), m.end(), word, new, origin))
            cursor = m.end()
        pieces.append(text[cursor:])
        return TransformResult(text, "".join(pieces), self.dialect, mode, changes)
