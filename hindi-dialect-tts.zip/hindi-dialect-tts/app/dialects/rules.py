"""Character-level dialect rules (paper Table 4: "Dialect Characters Variations").

Each rule rewrites a *single Hindi word* (rules never cross word boundaries)
into the spelling that makes a Hindi TTS front-end pronounce it the way a
speaker of the target dialect would. Rules have a ``level``:

* ``conservative`` – regular, high-precision sound correspondences
  (e.g. Haryanvi श→स, word-final थ→त; Awadhi ण→न).
* ``full`` – every pattern reported in the paper, including ones that only
  hold for part of the vocabulary (e.g. Chhattisgarhi word-initial स→छ).
  Use for experiments; prefer the lexicon for production.

Rules are deliberately data, not code paths, so a linguist can review
``RULES`` without reading the transformer.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Literal

from .devanagari import (
    ANUSVARA,
    CHANDRABINDU,
    LONG_INDEPENDENT_VOWEL,
    LONG_MATRA,
    MATRA,
    NUKTA,
    RRA,
    VIRAMA,
    geminate,
)

Level = Literal["conservative", "full"]
LEVEL_ORDER = {"conservative": 0, "full": 1}


@dataclass(frozen=True)
class Dialect:
    code: str
    name: str
    hindi_name: str
    region: str
    is_reference: bool = False


DIALECTS: dict[str, Dialect] = {
    d.code: d
    for d in [
        Dialect("khadiboli", "Khadi Boli", "खड़ी बोली", "Western UP, Delhi (reference dialect)", True),
        Dialect("haryanvi", "Haryanvi", "हरियाणवी", "Haryana, Delhi"),
        Dialect("chhattisgarhi", "Chhattisgarhi", "छत्तीसगढ़ी", "Chhattisgarh and adjacent areas"),
        Dialect("awadhi", "Awadhi", "अवधी", "Central/Eastern Uttar Pradesh"),
        Dialect("brajbhasha", "Braj Bhasha", "ब्रजभाषा", "Mathura-Agra region, UP"),
        Dialect("bihari", "Bihari", "बिहारी", "Bihar"),
        Dialect("bundeli", "Bundeli / Bundelkhandi", "बुंदेली", "Bundelkhand (MP and southern UP)"),
    ]
}
REFERENCE_DIALECT = "khadiboli"


@dataclass(frozen=True)
class Rule:
    id: str
    dialect: str
    pattern: str
    repl: str | Callable[[re.Match], str]
    description: str
    level: Level = "conservative"
    examples: tuple[tuple[str, str], ...] = field(default_factory=tuple)

    def compiled(self) -> re.Pattern:
        return _compile(self.pattern)

    def apply(self, word: str) -> str:
        return self.compiled().sub(self.repl, word)


_CACHE: dict[str, re.Pattern] = {}


def _compile(pattern: str) -> re.Pattern:
    if pattern not in _CACHE:
        _CACHE[pattern] = re.compile(pattern)
    return _CACHE[pattern]


# --------------------------------------------------------------------------
# Gemination ("single consonant is replaced by dual consonant")
# राजा→राज्जा, चाचा→चाच्चा, आलू→आल्लू, ढीला→ढील्ला, हँसी→हँस्सी, गाड़ी→गाड्डी,
# देखा→देक्खा (aspirate geminates as unaspirated + virama + aspirate).
# Context: after a long vowel (or a nasalised vowel), before a word-final vowel.
# --------------------------------------------------------------------------
def _gemination_pattern(excluded: str, short_initial: bool = False) -> str:
    alts = [LONG_MATRA, f"^{LONG_INDEPENDENT_VOWEL}", f"[{CHANDRABINDU}{ANUSVARA}]"]
    if short_initial:   # Khadi Boli also doubles after a short first syllable: बड़ा→बड्डा
        alts.append(r"^[\u0915-\u0939]")
    left = "(?:" + "|".join(alts) + ")"
    cons = rf"(?![{excluded}])[क-ह]{NUKTA}?"
    final_vowel = "[ाीूेो]$"      # ा ी ू े ो
    return rf"(?P<left>{left})(?P<c>{cons})(?={final_vowel})"


def _geminate_repl(m: re.Match) -> str:
    c = m.group("c")
    if c.endswith(NUKTA) and c[0] != "ड":     # only ड़ geminates among nukta letters
        return m.group(0)
    return m.group("left") + geminate(c)


# Haryanvi changes न→ण separately, so nasals are not geminated there.
_HAR_GEM = _gemination_pattern("नणमयरहवशष")
_KHADI_GEM = _gemination_pattern("णयरहवशष", short_initial=True)


RULES: list[Rule] = [
    # ---------------------------------------------------------------- Haryanvi
    Rule("har_sha_sa", "haryanvi", "[शष]", "स", "श/ष are pronounced स", "conservative",
         (("आकाश", "आकास"),)),
    Rule("har_tha_ta_final", "haryanvi", "थ$", "त", "word-final थ → त", "conservative",
         (("हाथ", "हात"), ("साथ", "सात"))),
    Rule("har_na_nna", "haryanvi", rf"(?<=[ऀ-ॿ])(?<!{VIRAMA})न(?!{VIRAMA})", "ण",
         "non-initial न → ण (retroflex nasal)", "conservative",
         (("अपने", "अपणे"), ("खाना", "खाणा"), ("चना", "चणा"))),
    Rule("har_rra_ra", "haryanvi", RRA, "र", "ड़ → र", "full", (("कीड़ी", "कीरी"),)),
    Rule("har_la_ra", "haryanvi", "(?<=ा)ल(?=ा$)", "र", "intervocalic ल → र (आ_आ)", "full",
         (("काला", "कारा"),)),
    Rule("har_gemination", "haryanvi", _HAR_GEM, _geminate_repl,
         "consonant after a long vowel is doubled", "full",
         (("राजा", "राज्जा"), ("चाचा", "चाच्चा"), ("आलू", "आल्लू"), ("ढीला", "ढील्ला"),
          ("हँसी", "हँस्सी"), ("आँसू", "आँस्सू"), ("ऊँचा", "ऊँच्चा"), ("गाड़ी", "गाड्डी"))),

    # ----------------------------------------------------------- Chhattisgarhi
    Rule("chh_chah_chhe", "chhattisgarhi", "चह", "छे", "चह → छे", "conservative",
         (("कचहरी", "कछेरी"),)),
    Rule("chh_aa_e_ye", "chhattisgarhi", "(?<=[ाआ])ए", "ये", "ए after आ/ा → ये", "conservative",
         (("आए", "आये"),)),
    Rule("chh_ja_jha", "chhattisgarhi", rf"^ज(?![{NUKTA}{VIRAMA}])", "झ", "initial ज → झ", "full",
         (("जन", "झन"),)),
    Rule("chh_da_dha", "chhattisgarhi", rf"^द(?![{NUKTA}{VIRAMA}])", "ध", "initial द → ध", "full",
         (("दौड़", "धौड़"),)),
    Rule("chh_ka_kha", "chhattisgarhi", rf"(?<={MATRA})क(?={MATRA}$)", "ख",
         "intervocalic final-syllable क → ख", "full", (("इलाका", "इलाखा"),)),
    Rule("chh_sa_chha", "chhattisgarhi", rf"^स(?!{VIRAMA})", "छ", "initial स → छ", "full",
         (("सीता", "छीता"),)),
    Rule("chh_ba_pa_final", "chhattisgarhi", "ब$", "प", "word-final ब → प", "full",
         (("शराब", "शराप"), ("खराब", "खराप"))),
    Rule("chh_ma_va_final", "chhattisgarhi", "(?<=ा)म$", "व", "word-final म after आ → व", "full",
         (("नाम", "नाव"),)),
    Rule("chh_ga_ka", "chhattisgarhi", "(?<=[क-ह])ग(?=ी$)", "क", "ग → क before final ी", "full",
         (("बंदगी", "बंदकी"),)),

    # ------------------------------------------------------------------ Awadhi
    Rule("awa_nna_na", "awadhi", "ण", "न", "ण → न", "conservative",
         (("गुण", "गुन"), ("लक्ष्मण", "लक्ष्मन"))),
    Rule("awa_va_ba", "awadhi", "^व", "ब", "initial व → ब", "conservative",
         (("वाहन", "बाहन"), ("वन", "बन"), ("व्याकुल", "ब्याकुल"))),
    Rule("awa_sha_sa", "awadhi", "[शष]", "स", "श/ष → स", "conservative",
         (("शंकर", "संकर"), ("शाम", "साम"), ("शेर", "सेर"))),
    Rule("awa_ri", "awadhi", "ऋ", "रि", "ऋ → रि", "conservative", (("ऋतु", "रितु"),)),
    Rule("awa_ri_matra", "awadhi", "ृ", VIRAMA + "रि", "vowel sign ृ → ्रि", "full",
         (("कृपा", "क्रिपा"),)),
    Rule("awa_prothetic_i", "awadhi", rf"^स{VIRAMA}(?=[कटतपथमन])", "इस" + VIRAMA,
         "prothetic इ before initial स-cluster", "conservative",
         (("स्कूल", "इस्कूल"), ("स्त्री", "इस्त्री"))),
    Rule("awa_rra_ra", "awadhi", RRA, "र", "ड़ → र", "full", (("किवाड़", "किवार"),)),
    Rule("awa_da_dda", "awadhi", rf"^द(?![{NUKTA}{VIRAMA}])", "ड", "initial द → ड", "full",
         (("दंड", "डंड"),)),

    # ------------------------------------------------------------- Braj Bhasha
    Rule("bra_rra_ra", "brajbhasha", RRA, "र", "ड़ → र", "conservative",
         (("पड़े", "परे"), ("सड़क", "सरक"))),
    Rule("bra_on_un", "brajbhasha", "ों", "ूँ", "ों → ूँ", "conservative",
         (("क्यों", "क्यूँ"), ("गोंद", "गूँद"))),
    Rule("bra_la_ra", "brajbhasha", rf"(?<=[ऀ-ॿ])(?<!{VIRAMA})ल(?!{VIRAMA})", "र",
         "non-initial ल → र", "full", (("काला", "कारा"), ("तले", "तरे"), ("बल", "बर"))),

    # ------------------------------------------------------------------ Bihari
    Rule("bih_rra_ra", "bihari", RRA, "र", "ड़ → र", "conservative",
         (("लड़का", "लरका"), ("कड़ी", "करी"))),

    # -------------------------------------------------------------- Khadi Boli
    Rule("khb_gemination", "khadiboli", _KHADI_GEM, _geminate_repl,
         "consonant after a long vowel is doubled (aspirates as unaspirated+aspirate)", "full",
         (("बेटा", "बेट्टा"), ("भेजा", "भेज्जा"), ("बड़ा", "बड्डा"), ("छोटा", "छोट्टा"),
          ("रानी", "रान्नी"), ("सादी", "साद्दी"), ("रोटी", "रोट्टी"), ("देखा", "देक्खा"))),
]


def rules_for(dialect: str, level: Level = "conservative") -> list[Rule]:
    """Rules of a dialect up to (and including) ``level``, in application order."""
    if dialect not in DIALECTS:
        raise KeyError(f"unknown dialect {dialect!r}; known: {sorted(DIALECTS)}")
    if level not in LEVEL_ORDER:
        raise ValueError(f"level must be one of {list(LEVEL_ORDER)}")
    cap = LEVEL_ORDER[level]
    return [r for r in RULES if r.dialect == dialect and LEVEL_ORDER[r.level] <= cap]
