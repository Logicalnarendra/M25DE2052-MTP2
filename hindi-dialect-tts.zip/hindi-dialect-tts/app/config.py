"""Runtime settings from environment variables (see .env.example)."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _load_dotenv(path: Path = ROOT / ".env") -> None:
    """Minimal .env loader (no dependency); real env vars win."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.split(" #", 1)[0]                     # allow trailing comments
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_dotenv()


@dataclass(frozen=True)
class Settings:
    database_url: str = field(default_factory=lambda: os.getenv(
        "DATABASE_URL", f"sqlite:///{ROOT / 'data' / 'app.db'}"))
    tts_engine: str = field(default_factory=lambda: os.getenv("TTS_ENGINE", "indic_tts"))
    audio_dir: Path = field(default_factory=lambda: Path(os.getenv("AUDIO_DIR", str(ROOT / "data" / "audio"))))
    lexicon_dir: Path = field(default_factory=lambda: Path(os.getenv("LEXICON_DIR", str(ROOT / "data" / "lexicon"))))
    rule_level: str = field(default_factory=lambda: os.getenv("RULE_LEVEL", "conservative"))
    reference_dialect: str = field(default_factory=lambda: os.getenv("REFERENCE_DIALECT", "khadiboli"))
    admin_token: str = field(default_factory=lambda: os.getenv("ADMIN_TOKEN", ""))


def get_settings() -> Settings:
    return Settings()
