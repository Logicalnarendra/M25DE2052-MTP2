"""Engine registry."""
from __future__ import annotations

import os
from functools import lru_cache

from .base import TTSEngine, TTSError, read_wav, to_wav_bytes, write_wav
from .mock import MockTTSEngine

ENGINES = ("indic_tts", "mock")


@lru_cache(maxsize=4)
def get_engine(name: str | None = None) -> TTSEngine:
    name = name or os.getenv("TTS_ENGINE", "indic_tts")
    if name == "mock":
        return MockTTSEngine()
    if name == "indic_tts":
        from .indic_tts import IndicTTSEngine
        return IndicTTSEngine(
            model_dir=os.getenv("INDIC_TTS_MODEL_DIR", "models/indic-tts"),
            lang=os.getenv("INDIC_TTS_LANG", "hi"),
            use_cuda=os.getenv("TTS_USE_CUDA", "0") == "1",
        )
    raise TTSError(f"unknown TTS engine {name!r}; choose from {ENGINES}")


__all__ = ["TTSEngine", "TTSError", "MockTTSEngine", "get_engine", "ENGINES",
           "to_wav_bytes", "write_wav", "read_wav"]
