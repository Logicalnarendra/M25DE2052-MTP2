"""Engine-agnostic TTS interface + WAV helpers."""
from __future__ import annotations

import io
import wave
from abc import ABC, abstractmethod
from pathlib import Path

import numpy as np

from ..dialects.ssml import flatten_ssml


class TTSError(RuntimeError):
    pass


class TTSEngine(ABC):
    """Every engine returns mono float32 audio in [-1, 1] at ``sample_rate``."""

    name: str = "base"
    supports_ssml: bool = False
    speakers: tuple[str, ...] = ("female", "male")

    @property
    @abstractmethod
    def sample_rate(self) -> int: ...

    @abstractmethod
    def synthesize(self, text: str, speaker: str = "female", rate: float = 1.0) -> np.ndarray: ...

    def synthesize_ssml(self, ssml: str, speaker: str = "female") -> np.ndarray:
        """Default SSML path: flatten to segments, synthesise, join with silences."""
        parts: list[np.ndarray] = []
        for seg in flatten_ssml(ssml):
            if seg.pause_ms:
                parts.append(np.zeros(int(self.sample_rate * seg.pause_ms / 1000), dtype=np.float32))
            if seg.text:
                parts.append(self.synthesize(seg.text, speaker=speaker, rate=seg.rate))
        if not parts:
            return np.zeros(0, dtype=np.float32)
        return np.concatenate(parts).astype(np.float32)

    def check_speaker(self, speaker: str) -> None:
        if speaker not in self.speakers:
            raise TTSError(f"{self.name}: unknown speaker {speaker!r}; choose from {self.speakers}")


def to_wav_bytes(audio: np.ndarray, sample_rate: int) -> bytes:
    audio = np.clip(np.asarray(audio, dtype=np.float32), -1.0, 1.0)
    pcm = (audio * 32767.0).astype("<i2")
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(pcm.tobytes())
    return buf.getvalue()


def write_wav(path: str | Path, audio: np.ndarray, sample_rate: int) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(to_wav_bytes(audio, sample_rate))
    return path


def read_wav(path_or_bytes: str | Path | bytes) -> tuple[np.ndarray, int]:
    src = io.BytesIO(path_or_bytes) if isinstance(path_or_bytes, bytes) else open(path_or_bytes, "rb")
    with src, wave.open(src, "rb") as w:
        sr = w.getframerate()
        pcm = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2")
    return pcm.astype(np.float32) / 32767.0, sr
