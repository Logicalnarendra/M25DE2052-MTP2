"""Deterministic offline engine for tests and CI (no model download).

Each Devanagari code point becomes a short tone whose pitch is derived from
the code point, so different spellings (e.g. हाथ vs हात) give different audio
and the duration scales with text length and speaking rate.
"""
from __future__ import annotations

import numpy as np

from .base import TTSEngine


class MockTTSEngine(TTSEngine):
    name = "mock"
    supports_ssml = False
    speakers = ("female", "male")

    def __init__(self, sample_rate: int = 16000, ms_per_char: int = 60):
        self._sr = sample_rate
        self.ms_per_char = ms_per_char

    @property
    def sample_rate(self) -> int:
        return self._sr

    def synthesize(self, text: str, speaker: str = "female", rate: float = 1.0) -> np.ndarray:
        self.check_speaker(speaker)
        base = 220.0 if speaker == "female" else 120.0
        n = max(1, int(self._sr * self.ms_per_char / 1000 / max(rate, 0.1)))
        t = np.arange(n) / self._sr
        env = np.hanning(n).astype(np.float32)
        chunks = []
        for ch in text:
            if ch.isspace():
                chunks.append(np.zeros(n // 2, dtype=np.float32))
                continue
            f = base + (ord(ch) % 64) * 8.0
            chunks.append((0.3 * np.sin(2 * np.pi * f * t)).astype(np.float32) * env)
        return np.concatenate(chunks) if chunks else np.zeros(0, dtype=np.float32)
