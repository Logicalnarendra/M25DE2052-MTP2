"""AI4Bharat Indic-TTS adapter (FastPitch acoustic model + HiFi-GAN vocoder).

Checkpoints: https://github.com/AI4Bharat/Indic-TTS/releases (``hi.zip``).
Run ``python scripts/download_indic_tts.py`` to fetch and unpack them into
``models/indic-tts/hi`` and patch the speaker-file paths inside the configs.

Expected layout::

    models/indic-tts/hi/fastpitch/{best_model.pth, config.json, speakers.pth}
    models/indic-tts/hi/hifigan/{best_model.pth, config.json}

Requires the Coqui TTS runtime (``pip install -r requirements-tts.txt``).
Indic-TTS has no SSML support, so SSML is flattened by the base class and the
dialect forms reach the model as plain Devanagari text.
"""
from __future__ import annotations

import logging
import threading
from pathlib import Path

import numpy as np

from .base import TTSEngine, TTSError

log = logging.getLogger(__name__)


class IndicTTSEngine(TTSEngine):
    name = "indic_tts"
    supports_ssml = False
    speakers = ("female", "male")

    def __init__(self, model_dir: str | Path, lang: str = "hi", use_cuda: bool = False):
        self.root = Path(model_dir) / lang
        self.use_cuda = use_cuda
        self._synth = None
        self._lock = threading.Lock()

    # -- paths ---------------------------------------------------------------
    def paths(self) -> dict[str, Path]:
        fp, hg = self.root / "fastpitch", self.root / "hifigan"
        return {
            "tts_checkpoint": fp / "best_model.pth",
            "tts_config_path": fp / "config.json",
            "tts_speakers_file": fp / "speakers.pth",
            "vocoder_checkpoint": hg / "best_model.pth",
            "vocoder_config": hg / "config.json",
        }

    def missing_files(self) -> list[Path]:
        return [p for p in self.paths().values() if not p.exists()]

    # -- lazy load -------------------------------------------------------------
    def load(self):
        if self._synth is not None:
            return self._synth
        missing = self.missing_files()
        if missing:
            raise TTSError(
                "Indic-TTS checkpoints not found: " + ", ".join(map(str, missing))
                + ". Run `python scripts/download_indic_tts.py` or set INDIC_TTS_MODEL_DIR.")
        try:
            from TTS.utils.synthesizer import Synthesizer  # coqui-tts
        except ImportError as exc:  # pragma: no cover - depends on optional extra
            raise TTSError("Coqui TTS is not installed: pip install -r requirements-tts.txt") from exc
        p = self.paths()
        log.info("loading Indic-TTS from %s (cuda=%s)", self.root, self.use_cuda)
        self._synth = Synthesizer(
            tts_checkpoint=str(p["tts_checkpoint"]),
            tts_config_path=str(p["tts_config_path"]),
            tts_speakers_file=str(p["tts_speakers_file"]),
            vocoder_checkpoint=str(p["vocoder_checkpoint"]),
            vocoder_config=str(p["vocoder_config"]),
            use_cuda=self.use_cuda,
        )
        return self._synth

    @property
    def sample_rate(self) -> int:
        return int(self.load().output_sample_rate)

    def synthesize(self, text: str, speaker: str = "female", rate: float = 1.0) -> np.ndarray:
        self.check_speaker(speaker)
        if not text.strip():
            return np.zeros(0, dtype=np.float32)
        synth = self.load()
        with self._lock:
            model = getattr(synth, "tts_model", None)
            old_scale = getattr(model, "length_scale", None)
            if rate != 1.0:
                if old_scale is not None:
                    model.length_scale = old_scale / rate      # FastPitch: >1 = slower
                else:
                    log.warning("speaking-rate control unavailable for this checkpoint")
            try:
                wav = synth.tts(text, speaker_name=speaker)
            finally:
                if old_scale is not None:
                    model.length_scale = old_scale
        return np.asarray(wav, dtype=np.float32)
