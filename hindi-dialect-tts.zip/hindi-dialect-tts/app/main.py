"""FastAPI application.

    uvicorn app.main:app --reload          # http://127.0.0.1:8000  (docs at /docs)
"""
from __future__ import annotations

import random
from pathlib import Path
from urllib.parse import quote

from fastapi import Depends, FastAPI, File, Header, HTTPException, Query, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, Response
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from . import services
from .api.schemas import (EvaluatorIn, EvaluatorOut, NextSampleOut, RatingIn, SynthesizeRequest,
                          TransformRequest, TransformResponse)
from .config import Settings, get_settings
from .db import Database
from .dialects import DIALECTS, to_pls
from .models import AudioSample, Evaluator, Rating
from .tts import TTSEngine, TTSError, get_engine, to_wav_bytes

STATIC = Path(__file__).parent / "static"


def create_app(settings: Settings | None = None, engine: TTSEngine | None = None) -> FastAPI:
    settings = settings or get_settings()
    database = Database(settings.database_url)
    database.create_all()
    with database.SessionLocal() as s:
        services.seed_dialects(s)
        services.seed_lexicon(s, settings.lexicon_dir)

    app = FastAPI(title="Dialect-aware Hindi TTS & bias-corrected evaluation", version="1.0.0")
    app.state.settings = settings
    app.state.db = database
    app.state._engine = engine

    def get_db():
        yield from database.session()

    def tts() -> TTSEngine:
        if app.state._engine is None:
            app.state._engine = get_engine(settings.tts_engine)
        return app.state._engine

    def require_admin(x_admin_token: str = Header(default="")):
        if settings.admin_token and x_admin_token != settings.admin_token:
            raise HTTPException(401, "invalid admin token")

    # ------------------------------------------------------------------ basics
    @app.get("/", response_class=HTMLResponse, include_in_schema=False)
    def index():
        return (STATIC / "listening_test.html").read_text(encoding="utf-8")

    @app.get("/health")
    def health():
        return {"status": "ok", "engine": settings.tts_engine}

    @app.get("/dialects")
    def dialects():
        return [vars(d) for d in DIALECTS.values()]

    # --------------------------------------------------------------- synthesis
    @app.post("/transform", response_model=TransformResponse)
    def transform(req: TransformRequest, db: Session = Depends(get_db)):
        if req.dialect not in DIALECTS:
            raise HTTPException(422, f"unknown dialect {req.dialect}")
        result, ssml = services.render(req.text, req.dialect, req.mode, req.level,
                                       services.load_lexicon(db))
        return TransformResponse(original=result.original, text=result.text, dialect=result.dialect,
                                 mode=result.mode, changes=[vars(c) for c in result.changes], ssml=ssml)

    @app.post("/synthesize", responses={200: {"content": {"audio/wav": {}}}})
    def synthesize(req: SynthesizeRequest, db: Session = Depends(get_db)):
        if req.dialect not in DIALECTS:
            raise HTTPException(422, f"unknown dialect {req.dialect}")
        engine = tts()
        try:
            if req.ssml:
                audio = engine.synthesize_ssml(req.ssml, speaker=req.speaker)
                rendered = ""
            else:
                result, ssml = services.render(req.text, req.dialect, req.mode, req.level,
                                               services.load_lexicon(db))
                audio = engine.synthesize_ssml(ssml, speaker=req.speaker)
                rendered = result.text
        except TTSError as exc:
            raise HTTPException(503, str(exc)) from exc
        except ValueError as exc:                      # malformed SSML
            raise HTTPException(422, str(exc)) from exc
        headers = {"X-Rendered-Text": quote(rendered)}      # percent-encoded (headers are latin-1)
        return Response(to_wav_bytes(audio, engine.sample_rate), media_type="audio/wav", headers=headers)

    @app.get("/lexicon/{dialect}.pls")
    def lexicon_pls(dialect: str, db: Session = Depends(get_db)):
        if dialect not in DIALECTS:
            raise HTTPException(404, "unknown dialect")
        return Response(to_pls(services.load_lexicon(db), dialect), media_type="application/pls+xml")

    # -------------------------------------------------------------- evaluators
    @app.post("/evaluators", response_model=EvaluatorOut, status_code=201)
    def create_evaluator(body: EvaluatorIn, db: Session = Depends(get_db)):
        try:
            d = services.dialect_by_code(db, body.dialect)
        except KeyError as exc:
            raise HTTPException(422, str(exc)) from exc
        ev = Evaluator(code=body.code, dialect_id=d.id, native_place=body.native_place, state=body.state,
                       age=body.age, gender=body.gender, education=body.education)
        db.add(ev)
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
            raise HTTPException(409, f"evaluator {body.code!r} exists") from None
        return EvaluatorOut(id=ev.id, **body.model_dump())

    @app.get("/evaluators", response_model=list[EvaluatorOut])
    def list_evaluators(db: Session = Depends(get_db)):
        return [EvaluatorOut(id=e.id, code=e.code, dialect=e.dialect.code, native_place=e.native_place,
                             state=e.state, age=e.age, gender=e.gender, education=e.education)
                for e in db.scalars(select(Evaluator))]

    # ---------------------------------------------------------- listening test
    @app.get("/test/next", response_model=NextSampleOut | None)
    def test_next(evaluator_id: int, test_type: str = Query("MOS", pattern="^(MOS|DMOS)$"),
                  db: Session = Depends(get_db)):
        ev = db.get(Evaluator, evaluator_id)
        if ev is None:
            raise HTTPException(404, "evaluator not found")
        picked = services.next_sample(db, ev, test_type, random.Random())
        if picked is None:
            return None
        sample, ref = picked
        return NextSampleOut(sample_id=sample.id, audio_url=f"/audio/{sample.id}",
                             reference_url=f"/audio/{ref.id}" if ref else None, test_type=test_type)

    @app.get("/audio/{sample_id}")
    def audio(sample_id: int, db: Session = Depends(get_db)):
        s = db.get(AudioSample, sample_id)
        if s is None or not Path(s.path).exists():
            raise HTTPException(404, "audio not found")
        # served by opaque id only: the URL never reveals the system to the listener
        return FileResponse(s.path, media_type="audio/wav")

    @app.post("/ratings", status_code=201)
    def rate(body: RatingIn, db: Session = Depends(get_db)):
        if db.get(Evaluator, body.evaluator_id) is None or db.get(AudioSample, body.sample_id) is None:
            raise HTTPException(404, "evaluator or sample not found")
        db.add(Rating(evaluator_id=body.evaluator_id, sample_id=body.sample_id,
                      test_type=body.test_type, score=body.score))
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
            raise HTTPException(409, "already rated") from None
        return {"ok": True}

    # ----------------------------------------------------------------- results
    @app.get("/results")
    def results(test_type: str = Query("MOS", pattern="^(MOS|DMOS)$"),
                correction: str = Query("none", pattern="^(none|paper_regression|offset|zscore|mixed)$"),
                weighting: str = Query("none", pattern="^(none|equal|population|inverse_var)$"),
                db: Session = Depends(get_db)):
        df = services.ratings_frame(db, test_type)
        try:
            return services.compute_results(df, correction, weighting, settings.reference_dialect)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.get("/results/ratings.csv")
    def ratings_csv(test_type: str = "MOS", db: Session = Depends(get_db)):
        return Response(services.ratings_frame(db, test_type).to_csv(index=False), media_type="text/csv")

    # ------------------------------------------------------------------- admin
    @app.post("/admin/seed", dependencies=[Depends(require_admin)])
    def admin_seed(speakers: str = "female", db: Session = Depends(get_db)):
        return services.seed_all(db, settings.tts_engine, tuple(speakers.split(",")))

    @app.post("/admin/generate", dependencies=[Depends(require_admin)])
    def admin_generate(db: Session = Depends(get_db)):
        try:
            n = services.generate_samples(db, tts(), settings.audio_dir, settings.rule_level)
        except TTSError as exc:
            raise HTTPException(503, str(exc)) from exc
        return {"generated": n}

    @app.post("/admin/natural/{sentence_id}", dependencies=[Depends(require_admin)])
    async def admin_natural(sentence_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
        data = await file.read()
        if not data.startswith(b"RIFF"):
            raise HTTPException(422, "upload a WAV file")
        try:
            s = services.add_natural_recording(db, sentence_id, data, settings.audio_dir)
        except KeyError as exc:
            raise HTTPException(404, str(exc)) from exc
        return {"sample_id": s.id}

    return app


app = create_app()
