from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

ModeT = Literal["standard", "char", "lexicon", "combined"]
LevelT = Literal["conservative", "full"]
TestT = Literal["MOS", "DMOS"]


class TransformRequest(BaseModel):
    text: str = Field(min_length=1, max_length=5000)
    dialect: str = "haryanvi"
    mode: ModeT = "combined"
    level: LevelT = "conservative"


class ChangeOut(BaseModel):
    start: int
    end: int
    source: str
    target: str
    origin: str


class TransformResponse(BaseModel):
    original: str
    text: str
    dialect: str
    mode: str
    changes: list[ChangeOut]
    ssml: str


class SynthesizeRequest(TransformRequest):
    speaker: Literal["female", "male"] = "female"
    ssml: str | None = Field(default=None, max_length=20000,
                             description="If given, synthesise this SSML instead of `text`.")


class EvaluatorIn(BaseModel):
    code: str = Field(min_length=1, max_length=64)
    dialect: str
    native_place: str = ""
    state: str = ""
    age: int | None = Field(default=None, ge=10, le=110)
    gender: str = ""
    education: str = ""


class EvaluatorOut(EvaluatorIn):
    id: int


class NextSampleOut(BaseModel):
    sample_id: int
    audio_url: str
    reference_url: str | None = None
    test_type: TestT
    remaining: int | None = None


class RatingIn(BaseModel):
    evaluator_id: int
    sample_id: int
    test_type: TestT = "MOS"
    score: float = Field(ge=1, le=5)
