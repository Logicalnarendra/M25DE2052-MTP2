"""Business logic shared by the API and the CLI scripts."""
from __future__ import annotations

import csv
import random
from pathlib import Path

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from .dialects import DIALECTS, DialectTransformer, Lexicon, LexiconEntry, to_ssml
from .dialects.lexicon import DEFAULT_LEXICON_DIR
from .evaluation.report import compute_results  # noqa: F401  (re-exported for the API)
from .models import AudioSample, Dialect, Evaluator, LexiconEntryRow, Rating, Sentence, TTSSystem
from .tts import TTSEngine, write_wav

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SENTENCES = ROOT / "data" / "sentences_hi.csv"
DEFAULT_TARGETS = ("haryanvi", "chhattisgarhi")
DEFAULT_MODES = ("char", "lexicon")          # the paper's two dialect conditions


# ------------------------------------------------------------------ seeding
def seed_dialects(db: Session) -> None:
    existing = {d.code for d in db.scalars(select(Dialect))}
    for d in DIALECTS.values():
        if d.code not in existing:
            db.add(Dialect(code=d.code, name=d.name, hindi_name=d.hindi_name,
                           region=d.region, is_reference=d.is_reference))
    db.commit()


def dialect_by_code(db: Session, code: str) -> Dialect:
    d = db.scalar(select(Dialect).where(Dialect.code == code))
    if d is None:
        raise KeyError(f"unknown dialect {code!r}")
    return d


def seed_lexicon(db: Session, lexicon_dir: Path = DEFAULT_LEXICON_DIR) -> int:
    lex = Lexicon.from_dir(lexicon_dir)
    ids = {d.code: d.id for d in db.scalars(select(Dialect))}
    have = {(r.dialect_id, r.hindi) for r in db.scalars(select(LexiconEntryRow))}
    n = 0
    for e in lex.entries():
        if (ids[e.dialect], e.hindi) in have:
            continue
        db.add(LexiconEntryRow(dialect_id=ids[e.dialect], hindi=e.hindi, dialect_form=e.dialect_form,
                               pos=e.pos, source=e.source, verified=e.verified))
        n += 1
    db.commit()
    return n


def seed_sentences(db: Session, path: Path = DEFAULT_SENTENCES) -> int:
    if db.scalar(select(Sentence.id).limit(1)) is not None:
        return 0
    with path.open(encoding="utf-8", newline="") as fh:
        rows = list(csv.DictReader(fh))
    for r in rows:
        db.add(Sentence(id=int(r["id"]), text_hi=r["text_hi"], tags=r.get("tags", "")))
    db.commit()
    return len(rows)


def seed_systems(db: Session, engine_name: str, speakers=("female",),
                 targets=DEFAULT_TARGETS, modes=DEFAULT_MODES) -> int:
    have = {s.name for s in db.scalars(select(TTSSystem))}
    n = 0
    for spk in speakers:
        specs = [(f"hindi-standard-{spk}", "standard", None)]
        specs += [(f"{t}-{m}-{spk}", m, t) for t in targets for m in modes]
        for name, mode, target in specs:
            if name in have:
                continue
            db.add(TTSSystem(name=name, engine=engine_name, speaker=spk, mode=mode,
                             dialect_id=dialect_by_code(db, target).id if target else None))
            n += 1
    db.commit()
    return n


def seed_all(db: Session, engine_name: str, speakers=("female",)) -> dict:
    seed_dialects(db)
    return {"lexicon": seed_lexicon(db), "sentences": seed_sentences(db),
            "systems": seed_systems(db, engine_name, speakers)}


# ------------------------------------------------------------------ synthesis
def load_lexicon(db: Session) -> Lexicon:
    rows = db.scalars(select(LexiconEntryRow)).all()
    if not rows:
        return Lexicon.from_dir()
    return Lexicon(LexiconEntry(r.dialect.code, r.hindi, r.dialect_form, r.pos, r.source, r.verified)
                   for r in rows)


def render(text: str, dialect: str | None, mode: str, level: str, lexicon: Lexicon):
    if not dialect or mode == "standard":
        dialect, mode = dialect or "khadiboli", "standard"
    result = DialectTransformer(dialect, lexicon, level).transform(text, mode)  # type: ignore[arg-type]
    return result, to_ssml(result)


def generate_samples(db: Session, engine: TTSEngine, audio_dir: Path, level: str = "conservative") -> int:
    lexicon = load_lexicon(db)
    done = {(a.sentence_id, a.system_id) for a in db.scalars(select(AudioSample))}
    systems = db.scalars(select(TTSSystem).where(TTSSystem.is_natural.is_(False))).all()
    n = 0
    for sent in db.scalars(select(Sentence)).all():
        for sys_ in systems:
            if (sent.id, sys_.id) in done:
                continue
            result, ssml = render(sent.text_hi, sys_.dialect.code if sys_.dialect else None,
                                  sys_.mode, level, lexicon)
            audio = engine.synthesize_ssml(ssml, speaker=sys_.speaker)
            path = write_wav(audio_dir / sys_.name / f"{sent.id:04d}.wav", audio, engine.sample_rate)
            db.add(AudioSample(sentence_id=sent.id, system_id=sys_.id, path=str(path),
                               rendered_text=result.text, ssml=ssml,
                               duration_s=len(audio) / engine.sample_rate))
            n += 1
    db.commit()
    return n


def add_natural_recording(db: Session, sentence_id: int, wav_bytes: bytes, audio_dir: Path) -> AudioSample:
    nat = db.scalar(select(TTSSystem).where(TTSSystem.name == "natural"))
    if nat is None:
        nat = TTSSystem(name="natural", engine="human", mode="standard", is_natural=True)
        db.add(nat)
        db.flush()
    if db.get(Sentence, sentence_id) is None:
        raise KeyError(f"sentence {sentence_id} not found")
    path = audio_dir / "natural" / f"{sentence_id:04d}.wav"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(wav_bytes)
    sample = db.scalar(select(AudioSample).where(AudioSample.sentence_id == sentence_id,
                                                 AudioSample.system_id == nat.id))
    if sample is None:
        sample = AudioSample(sentence_id=sentence_id, system_id=nat.id, path=str(path))
        db.add(sample)
    db.commit()
    return sample


# ------------------------------------------------------------------ listening test
def next_sample(db: Session, evaluator: Evaluator, test_type: str,
                rng: random.Random | None = None) -> tuple[AudioSample, AudioSample | None] | None:
    """Random unrated synthetic sample (+ natural reference for DMOS). Blind: callers
    must not reveal the system to the listener."""
    rng = rng or random.Random()
    rated = set(db.scalars(select(Rating.sample_id).where(
        Rating.evaluator_id == evaluator.id, Rating.test_type == test_type)))
    q = select(AudioSample).join(TTSSystem).where(TTSSystem.is_natural.is_(False))
    candidates = [s for s in db.scalars(q).all() if s.id not in rated]
    refs: dict[int, AudioSample] = {}
    if test_type == "DMOS":
        nat_q = select(AudioSample).join(TTSSystem).where(TTSSystem.is_natural.is_(True))
        refs = {s.sentence_id: s for s in db.scalars(nat_q).all()}
        candidates = [s for s in candidates if s.sentence_id in refs]
    if not candidates:
        return None
    pick = rng.choice(candidates)
    return pick, refs.get(pick.sentence_id)


def ratings_frame(db: Session, test_type: str = "MOS") -> pd.DataFrame:
    q = (select(Rating, Evaluator, Dialect, AudioSample, TTSSystem)
         .join(Evaluator, Rating.evaluator_id == Evaluator.id)
         .join(Dialect, Evaluator.dialect_id == Dialect.id)
         .join(AudioSample, Rating.sample_id == AudioSample.id)
         .join(TTSSystem, AudioSample.system_id == TTSSystem.id)
         .where(Rating.test_type == test_type))
    rows = [{"rater_id": e.code, "rater_dialect": d.code, "system": s.name, "mode": s.mode,
             "speaker": s.speaker, "sentence_id": a.sentence_id, "score": float(r.score)}
            for r, e, d, a, s in db.execute(q).all()]
    cols = ["rater_id", "rater_dialect", "system", "mode", "speaker", "sentence_id", "score"]
    return pd.DataFrame(rows, columns=cols)
