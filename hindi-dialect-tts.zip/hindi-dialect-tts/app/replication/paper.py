"""Numbers published in Gupta, "Evaluating user preferences in Hindi Text-to-Speech"
(MeitY) and helpers that re-derive / check them.

Published artefacts used:
* Table 5   – per-evaluator mean grades, 10 evaluators × 3 conditions × 2 dialects
* Sec. 6.1  – regression coefficients + test-set predictions (Figs 3 & 4)
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from ..evaluation.stats import preference_table

DATA_DIR = Path(__file__).resolve().parents[2] / "data" / "paper"


@dataclass(frozen=True)
class PublishedRegression:
    dialect: str
    intercept: float
    coef: float
    test_actual: tuple[float, ...]       # Khadi Boli grades of the 4 held-out items
    test_predicted: tuple[float, ...]


PUBLISHED_REGRESSIONS = {
    "bundeli": PublishedRegression("bundeli", 4.75297619, -0.01190476,
                                   (3.5, 5.0, 4.5, 5.0), (4.729167, 4.711310, 4.711310, 4.729167)),
    "haryanvi": PublishedRegression("haryanvi", 4.56060606, 0.07575758,
                                    (3.5, 4.5, 5.0, 4.0), (4.712121, 4.825758, 4.863636, 4.863636)),
}


def table5() -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / "table5_evaluator_gradings.csv")


def table5_long() -> pd.DataFrame:
    """Long format: evaluator, dialect_sheet, condition, score."""
    wide = table5()
    long = wide.melt(id_vars="evaluator", var_name="col", value_name="score")
    long["dialect_sheet"] = long["col"].str.split("_").str[0].map({"chh": "chhattisgarhi", "har": "haryanvi"})
    long["condition"] = long["col"].str.split("_", n=1).str[1].map(
        {"hindi_tts": "standard", "char_variations": "char", "word_variations": "lexicon"})
    return long.drop(columns="col")


def table5_means() -> pd.DataFrame:
    return (table5_long().groupby(["dialect_sheet", "condition"])["score"]
            .agg(["mean", "std", "count"]).reset_index())


def table5_preferences() -> pd.DataFrame:
    """Paired tests: dialect-aware conditions vs. standard Hindi, per dialect sheet."""
    w = table5()
    out = []
    for p, name in (("chh", "chhattisgarhi"), ("har", "haryanvi")):
        t = preference_table(w, f"{p}_hindi_tts", [f"{p}_char_variations", f"{p}_word_variations"])
        t.insert(0, "dialect_sheet", name)
        out.append(t)
    return pd.concat(out, ignore_index=True)


def recover_test_inputs(reg: PublishedRegression) -> list[float]:
    """Invert y_hat = a·x + b to recover the held-out x (dialect) grades."""
    return [round((p - reg.intercept) / reg.coef, 3) for p in reg.test_predicted]


def check_published_regression(reg: PublishedRegression, tol: float = 1e-5) -> dict:
    xs = recover_test_inputs(reg)
    xs_grid = [round(x * 2) / 2 for x in xs]          # grades are on a 0.5 grid
    pred = [reg.coef * x + reg.intercept for x in xs_grid]
    err = float(np.max(np.abs(np.array(pred) - np.array(reg.test_predicted))))
    mae = float(np.mean(np.abs(np.array(reg.test_actual) - np.array(reg.test_predicted))))
    baseline = float(np.mean(np.abs(np.array(reg.test_actual) - np.mean(reg.test_actual))))
    return {"dialect": reg.dialect, "recovered_x": xs_grid, "max_abs_error": err,
            "consistent": err < tol, "test_mae": mae, "mean_predictor_mae": baseline}


def digitized_points() -> pd.DataFrame:
    return pd.read_csv(DATA_DIR / "regression_digitized_points.csv")


def refit_digitized() -> pd.DataFrame:
    """OLS on the visible (de-duplicated) points of Figs 3/4 – compare with published slope."""
    rows = []
    for d, g in digitized_points().groupby("dialect"):
        a, b = np.polyfit(g["x_dialect_score"], g["y_khadiboli_score"], 1)
        rows.append({"dialect": d, "n_visible_points": len(g), "slope_digitized": a,
                     "intercept_digitized": b, "slope_published": PUBLISHED_REGRESSIONS[d].coef,
                     "intercept_published": PUBLISHED_REGRESSIONS[d].intercept})
    return pd.DataFrame(rows)
