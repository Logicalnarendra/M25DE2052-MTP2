"""Dialect weighting for an aggregate (system-level) MOS.

Weights are applied to *dialect-group means*, so a dialect with many raters
does not dominate just by headcount.

* ``equal``       – every dialect group counts the same (recommended default
                    for a fairness-oriented score).
* ``population``  – proportional to speaker population (deployment-oriented).
* ``inverse_var`` – groups whose raters disagree more get less weight.
"""
from __future__ import annotations

from typing import Iterable, Mapping

import numpy as np
import pandas as pd

# Approximate mother-tongue speaker counts (millions), Census of India 2011,
# grouped under "Hindi". Verify against Census table C-16 before publishing.
# "khadiboli" stands in for the Census "Hindi" mother-tongue return;
# "bihari" uses Magahi as a proxy.
CENSUS_2011_SPEAKERS_M: dict[str, float] = {
    "khadiboli": 322.2,
    "chhattisgarhi": 16.2,
    "haryanvi": 9.8,
    "bihari": 12.7,
    "bundeli": 5.6,
    "awadhi": 3.9,
    "brajbhasha": 1.6,
}


def _normalise(w: Mapping[str, float]) -> dict[str, float]:
    total = float(sum(w.values()))
    if total <= 0:
        raise ValueError("weights must sum to a positive number")
    return {k: float(v) / total for k, v in w.items()}


def equal_weights(dialects: Iterable[str]) -> dict[str, float]:
    ds = sorted(set(dialects))
    return _normalise({d: 1.0 for d in ds})


def population_weights(dialects: Iterable[str],
                       table: Mapping[str, float] = CENSUS_2011_SPEAKERS_M) -> dict[str, float]:
    ds = sorted(set(dialects))
    unknown = [d for d in ds if d not in table]
    if unknown:
        raise KeyError(f"no population figure for {unknown}")
    return _normalise({d: table[d] for d in ds})


def inverse_variance_weights(df: pd.DataFrame, score_col: str = "score") -> dict[str, float]:
    w = {}
    for d, g in df.groupby("rater_dialect"):
        var = float(g[score_col].var(ddof=1)) if len(g) > 1 else np.nan
        w[d] = 1.0 / var if var and np.isfinite(var) and var > 0 else 1.0
    return _normalise(w)


def make_weights(scheme: str, df: pd.DataFrame, score_col: str = "score") -> dict[str, float]:
    dialects = df["rater_dialect"].unique()
    if scheme == "equal":
        return equal_weights(dialects)
    if scheme == "population":
        return population_weights(dialects)
    if scheme == "inverse_var":
        return inverse_variance_weights(df, score_col)
    raise ValueError("scheme must be equal | population | inverse_var")


def weighted_mos(df: pd.DataFrame, weights: Mapping[str, float], score_col: str = "score",
                 by: str = "system") -> pd.DataFrame:
    """Weighted mean of per-dialect means, renormalised over dialects present per system."""
    rows = []
    for key, g in df.groupby(by):
        means = g.groupby("rater_dialect")[score_col].mean()
        w = {d: weights.get(d, 0.0) for d in means.index}
        if sum(w.values()) == 0:
            raise ValueError(f"no weight for dialects {list(means.index)} in {key}")
        w = _normalise(w)
        rows.append({by: key, "weighted_mos": float(sum(means[d] * w[d] for d in w)),
                     "unweighted_mos": float(g[score_col].mean()),
                     "dialects": ",".join(sorted(w))})
    return pd.DataFrame(rows)
