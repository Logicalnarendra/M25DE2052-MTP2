"""MOS / DMOS aggregation with confidence intervals.

Ratings are a long-format DataFrame with at least:

    rater_id, rater_dialect, system, sentence_id, score   (+ optional test_type)

* MOS  – ACR scale (ITU-T P.800): 1 bad … 5 excellent.
* DMOS – DCR scale: listener hears natural reference then the synthetic
  sample; 5 = degradation inaudible … 1 = very annoying.

Both are aggregated identically; only the listening protocol differs.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Callable, Sequence

import numpy as np
import pandas as pd
from scipy import stats

REQUIRED_COLUMNS = ("rater_id", "rater_dialect", "system", "sentence_id", "score")


@dataclass(frozen=True)
class ScoreSummary:
    n: int
    mean: float
    std: float
    ci_low: float
    ci_high: float

    def as_dict(self) -> dict:
        return asdict(self)


def validate_ratings(df: pd.DataFrame, score_col: str = "score", lo: float = 1, hi: float = 5) -> None:
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns and c != "score"]
    if score_col not in df.columns:
        missing.append(score_col)
    if missing:
        raise ValueError(f"ratings frame missing columns: {missing}")
    s = df[score_col]
    if s.isna().any():
        raise ValueError("ratings contain NaN scores")
    if ((s < lo) | (s > hi)).any():
        raise ValueError(f"scores must lie in [{lo}, {hi}]")


def summarize(scores: Sequence[float], confidence: float = 0.95) -> ScoreSummary:
    """Mean with a Student-t confidence interval."""
    x = np.asarray(scores, dtype=float)
    n = int(x.size)
    if n == 0:
        return ScoreSummary(0, float("nan"), float("nan"), float("nan"), float("nan"))
    mean = float(x.mean())
    if n == 1:
        return ScoreSummary(1, mean, 0.0, mean, mean)
    sd = float(x.std(ddof=1))
    half = float(stats.t.ppf((1 + confidence) / 2, n - 1) * sd / np.sqrt(n))
    return ScoreSummary(n, mean, sd, mean - half, mean + half)


def mos_table(df: pd.DataFrame, by: Sequence[str] = ("system",), score_col: str = "score",
              confidence: float = 0.95) -> pd.DataFrame:
    rows = []
    for key, g in df.groupby(list(by), sort=True):
        key = key if isinstance(key, tuple) else (key,)
        rows.append({**dict(zip(by, key)), **summarize(g[score_col], confidence).as_dict()})
    return pd.DataFrame(rows)


def rater_bootstrap_ci(df: pd.DataFrame, statistic: Callable[[pd.DataFrame], float],
                       n_boot: int = 2000, confidence: float = 0.95, seed: int = 0) -> tuple[float, float]:
    """Cluster bootstrap over raters (ratings from one rater are not independent)."""
    rng = np.random.default_rng(seed)
    groups = {r: g for r, g in df.groupby("rater_id")}
    raters = np.array(list(groups))
    vals = []
    for _ in range(n_boot):
        pick = rng.choice(raters, size=len(raters), replace=True)
        vals.append(statistic(pd.concat([groups[r] for r in pick], ignore_index=True)))
    lo, hi = np.percentile(vals, [(1 - confidence) / 2 * 100, (1 + confidence) / 2 * 100])
    return float(lo), float(hi)
