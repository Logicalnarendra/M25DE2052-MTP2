"""Dialect-bias correction of listener scores.

All normalisers share ``fit(df) -> self`` / ``transform(df) -> df`` and add a
``score_corrected`` column, expressed on the *reference dialect's* scale
(Khadi Boli by default, as in the paper).

=====================  ==========================================================
``none``               raw scores
``paper_regression``   replication of the paper (Sec. 6.1): per dialect, fit
                       y_ref = a·x_dialect + b on item-level means of the same
                       sentences, then map that dialect's scores through it
``offset``             shift each dialect by its mean gap to the reference on
                       shared items (robust baseline)
``zscore``             per-rater standardisation, rescaled to the reference
                       group's mean/sd (removes leniency *and* scale-use bias)
``mixed``              linear mixed model  score ~ system + dialect + (1|rater);
                       removes the dialect fixed effect and the rater random
                       intercept (recommended; separates group bias from
                       individual leniency and keeps genuine system differences)
=====================  ==========================================================
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from ..dialects.rules import REFERENCE_DIALECT
from .mos import validate_ratings


class Normalizer(ABC):
    name = "base"

    def __init__(self, reference: str = REFERENCE_DIALECT, clip: bool = True):
        self.reference = reference
        self.clip = clip
        self.fitted_ = False

    @abstractmethod
    def fit(self, df: pd.DataFrame) -> "Normalizer": ...

    @abstractmethod
    def _correct(self, df: pd.DataFrame) -> pd.Series: ...

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        if not self.fitted_:
            raise RuntimeError(f"{self.name}: call fit() first")
        out = df.copy()
        corrected = self._correct(out).astype(float)
        out["score_corrected"] = corrected.clip(1.0, 5.0) if self.clip else corrected
        return out

    def fit_transform(self, df: pd.DataFrame) -> pd.DataFrame:
        return self.fit(df).transform(df)

    def _check(self, df: pd.DataFrame) -> None:
        validate_ratings(df)
        if self.reference not in set(df["rater_dialect"]):
            raise ValueError(f"no raters from reference dialect {self.reference!r}")


def _item_means(df: pd.DataFrame) -> pd.DataFrame:
    """Mean score per (system, sentence) for each dialect group, wide format."""
    return (df.groupby(["system", "sentence_id", "rater_dialect"])["score"].mean()
              .unstack("rater_dialect"))


# ----------------------------------------------------------------------------
class NoCorrection(Normalizer):
    name = "none"

    def fit(self, df):
        validate_ratings(df)
        self.fitted_ = True
        return self

    def _correct(self, df):
        return df["score"]


# ----------------------------------------------------------------------------
@dataclass
class RegressionFit:
    dialect: str
    coef: float                     # a  (slope)
    intercept: float                # b
    n_items: int
    r2_train: float
    test_x: list[float] = field(default_factory=list)
    test_y: list[float] = field(default_factory=list)
    test_pred: list[float] = field(default_factory=list)


class PaperRegressionNormalizer(Normalizer):
    """Replicates Gupta (MeitY) Sec. 6.1: ``LinearRegression`` with an 80/20
    ``train_test_split`` (sklearn defaults, ``random_state=0``), reference
    dialect on the y axis and the other dialect on the x axis."""

    name = "paper_regression"

    def __init__(self, reference: str = REFERENCE_DIALECT, test_size: float | None = 0.2,
                 random_state: int = 0, clip: bool = True):
        super().__init__(reference, clip)
        self.test_size = test_size
        self.random_state = random_state
        self.fits_: dict[str, RegressionFit] = {}

    def fit(self, df):
        from sklearn.linear_model import LinearRegression
        from sklearn.model_selection import train_test_split

        self._check(df)
        wide = _item_means(df)
        self.fits_ = {}
        for d in wide.columns:
            if d == self.reference:
                continue
            pair = wide[[d, self.reference]].dropna()
            if len(pair) < 3:
                raise ValueError(f"need >=3 shared items between {d} and {self.reference}")
            X, y = pair[[d]].to_numpy(), pair[self.reference].to_numpy()
            Xtr, Xte, ytr, yte = (X, X[:0], y, y[:0])
            if self.test_size and len(pair) >= 5:
                Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=self.test_size,
                                                      random_state=self.random_state)
            reg = LinearRegression().fit(Xtr, ytr)
            self.fits_[d] = RegressionFit(
                d, float(reg.coef_[0]), float(reg.intercept_), len(pair), float(reg.score(Xtr, ytr)),
                Xte[:, 0].tolist(), yte.tolist(), reg.predict(Xte).tolist() if len(Xte) else [])
        self.fitted_ = True
        return self

    def _correct(self, df):
        out = df["score"].astype(float).copy()
        for d, f in self.fits_.items():
            m = df["rater_dialect"] == d
            out[m] = f.coef * df.loc[m, "score"] + f.intercept
        return out


# ----------------------------------------------------------------------------
class OffsetNormalizer(Normalizer):
    name = "offset"

    def fit(self, df):
        self._check(df)
        wide = _item_means(df)
        self.offsets_ = {self.reference: 0.0}
        for d in wide.columns:
            if d == self.reference:
                continue
            pair = wide[[d, self.reference]].dropna()
            if pair.empty:
                raise ValueError(f"no shared items between {d} and {self.reference}")
            self.offsets_[d] = float((pair[self.reference] - pair[d]).mean())
        self.fitted_ = True
        return self

    def _correct(self, df):
        return df["score"] + df["rater_dialect"].map(self.offsets_).fillna(0.0)


# ----------------------------------------------------------------------------
class ZScoreNormalizer(Normalizer):
    name = "zscore"

    def fit(self, df):
        self._check(df)
        ref = df.loc[df["rater_dialect"] == self.reference, "score"]
        self.ref_mean_, self.ref_sd_ = float(ref.mean()), float(ref.std(ddof=1) or 1.0)
        g = df.groupby("rater_id")["score"]
        self.rater_mean_ = g.mean().to_dict()
        sd = g.std(ddof=1).fillna(0.0)
        self.rater_sd_ = sd.where(sd > 1e-9, 1.0).to_dict()   # constant raters: no rescale
        self.fitted_ = True
        return self

    def _correct(self, df):
        mu = df["rater_id"].map(self.rater_mean_)
        sd = df["rater_id"].map(self.rater_sd_)
        if mu.isna().any():
            raise ValueError("transform() got raters unseen during fit()")
        return (df["score"] - mu) / sd * self.ref_sd_ + self.ref_mean_


# ----------------------------------------------------------------------------
class MixedEffectsNormalizer(Normalizer):
    """score_ij = mu + system_j + dialect_d(i) + u_i + e_ij,  u_i ~ N(0, s_u^2).

    Uses statsmodels' REML ``MixedLM`` when available (``backend="auto"``),
    otherwise a self-contained alternating estimator with method-of-moments
    variance components and BLUP shrinkage of rater intercepts.
    """

    name = "mixed"

    def __init__(self, reference: str = REFERENCE_DIALECT, backend: str = "auto",
                 clip: bool = True, max_iter: int = 200, tol: float = 1e-8):
        super().__init__(reference, clip)
        self.backend = backend
        self.max_iter = max_iter
        self.tol = tol

    def fit(self, df):
        self._check(df)
        use_sm = self.backend == "statsmodels"
        if self.backend == "auto":
            try:
                import statsmodels.formula.api  # noqa: F401
                use_sm = True
            except ImportError:
                use_sm = False
        (self._fit_statsmodels if use_sm else self._fit_numpy)(df)
        self.backend_used_ = "statsmodels" if use_sm else "numpy"
        self.fitted_ = True
        return self

    def _fit_statsmodels(self, df):
        import statsmodels.formula.api as smf
        d = df.copy()
        formula = f"score ~ C(system) + C(rater_dialect, Treatment('{self.reference}'))"
        res = smf.mixedlm(formula, d, groups=d["rater_id"]).fit(reml=True)
        self.dialect_effects_ = {self.reference: 0.0}
        for name, val in res.fe_params.items():
            if name.startswith("C(rater_dialect"):
                self.dialect_effects_[name.split("[T.")[-1].rstrip("]")] = float(val)
        self.rater_effects_ = {k: float(v.iloc[0]) for k, v in res.random_effects.items()}
        self.var_rater_ = float(res.cov_re.iloc[0, 0])
        self.var_resid_ = float(res.scale)

    def _fit_numpy(self, df):
        systems = sorted(df["system"].unique())
        dialects = [x for x in sorted(df["rater_dialect"].unique()) if x != self.reference]
        cols = [np.ones(len(df))]
        cols += [(df["system"] == s).to_numpy(float) for s in systems[1:]]
        cols += [(df["rater_dialect"] == x).to_numpy(float) for x in dialects]
        X = np.column_stack(cols)
        y = df["score"].to_numpy(float)
        raters = df["rater_id"].to_numpy()
        codes, uniq = pd.factorize(raters)
        n_i = np.bincount(codes).astype(float)
        u = np.zeros(len(uniq))
        su2 = se2 = 0.0
        for _ in range(self.max_iter):
            beta, *_ = np.linalg.lstsq(X, y - u[codes], rcond=None)
            resid = y - X @ beta
            rbar = np.bincount(codes, weights=resid) / n_i
            within = resid - rbar[codes]
            dof = max(len(y) - len(uniq), 1)
            se2 = float((within ** 2).sum() / dof)
            su2 = max(0.0, float(np.var(rbar, ddof=1) - np.mean(se2 / n_i))) if len(uniq) > 1 else 0.0
            k = n_i * su2 / (n_i * su2 + se2) if se2 > 0 else np.ones_like(n_i)
            u_new = k * rbar
            if np.max(np.abs(u_new - u)) < self.tol:
                u = u_new
                break
            u = u_new
        beta, *_ = np.linalg.lstsq(X, y - u[codes], rcond=None)
        off = 1 + len(systems) - 1
        self.dialect_effects_ = {self.reference: 0.0,
                                 **{x: float(beta[off + i]) for i, x in enumerate(dialects)}}
        self.rater_effects_ = {r: float(v) for r, v in zip(uniq, u)}
        self.var_rater_, self.var_resid_ = su2, se2

    def _correct(self, df):
        de = df["rater_dialect"].map(self.dialect_effects_).fillna(0.0)
        re = df["rater_id"].map(self.rater_effects_).fillna(0.0)
        return df["score"] - de - re


NORMALIZERS = {
    c.name: c for c in (NoCorrection, PaperRegressionNormalizer, OffsetNormalizer,
                        ZScoreNormalizer, MixedEffectsNormalizer)
}


def get_normalizer(name: str, **kwargs) -> Normalizer:
    try:
        return NORMALIZERS[name](**kwargs)
    except KeyError:
        raise ValueError(f"unknown correction {name!r}; choose from {sorted(NORMALIZERS)}") from None
