"""Paired preference statistics (paper Table 5: same evaluators, three conditions)."""
from __future__ import annotations

from typing import Sequence

import numpy as np
import pandas as pd
from scipy import stats


def paired_comparison(baseline: Sequence[float], treatment: Sequence[float],
                      confidence: float = 0.95) -> dict:
    a, b = np.asarray(baseline, float), np.asarray(treatment, float)
    if a.shape != b.shape:
        raise ValueError("paired samples must have equal length")
    d = b - a
    n = d.size
    mean = float(d.mean())
    sd = float(d.std(ddof=1)) if n > 1 else 0.0
    half = float(stats.t.ppf((1 + confidence) / 2, n - 1) * sd / np.sqrt(n)) if n > 1 else 0.0
    nz = d[d != 0]
    if nz.size:
        w_p = float(stats.wilcoxon(b, a, zero_method="wilcox").pvalue)
    else:
        w_p = 1.0
    t_p = float(stats.ttest_rel(b, a).pvalue) if n > 1 and sd > 0 else 1.0
    return {
        "n": n, "mean_baseline": float(a.mean()), "mean_treatment": float(b.mean()),
        "mean_diff": mean, "ci_low": mean - half, "ci_high": mean + half,
        "cohens_dz": mean / sd if sd > 0 else float("nan"),
        "wilcoxon_p": w_p, "paired_t_p": t_p,
        "frac_prefer_treatment": float((d > 0).mean()),
        "frac_ties": float((d == 0).mean()),
    }


def holm(pvalues: Sequence[float]) -> list[float]:
    """Holm–Bonferroni adjusted p-values."""
    p = np.asarray(pvalues, float)
    order = np.argsort(p)
    adj = np.empty_like(p)
    running = 0.0
    for rank, idx in enumerate(order):
        running = max(running, min(1.0, (len(p) - rank) * p[idx]))
        adj[idx] = running
    return adj.tolist()


def preference_table(wide: pd.DataFrame, baseline: str, treatments: Sequence[str]) -> pd.DataFrame:
    rows = [{"treatment": t, **paired_comparison(wide[baseline], wide[t])} for t in treatments]
    out = pd.DataFrame(rows)
    out["wilcoxon_p_holm"] = holm(out["wilcoxon_p"])
    return out
