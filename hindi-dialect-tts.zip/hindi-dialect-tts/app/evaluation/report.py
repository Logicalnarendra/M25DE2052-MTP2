"""Turn a ratings frame into the results payload served by the API / reports."""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .bias import get_normalizer
from .mos import mos_table
from .stats import paired_comparison
from .weights import make_weights, weighted_mos


def compute_results(df: pd.DataFrame, correction: str = "none", weighting: str = "none",
                    reference: str = "khadiboli") -> dict:
    if df.empty:
        return {"n_ratings": 0, "systems": [], "by_dialect": [], "preferences": []}
    norm = get_normalizer(correction, reference=reference) if correction != "none" else get_normalizer("none")
    out = norm.fit_transform(df)
    col = "score_corrected"
    systems = mos_table(out, ("system",), col)
    if weighting != "none":
        w = make_weights(weighting, out, col)
        wm = weighted_mos(out, w, col).set_index("system")["weighted_mos"]
        systems["weighted_mos"] = systems["system"].map(wm)
    by_dialect = mos_table(out, ("system", "rater_dialect"), col)

    prefs = []
    per_rater = out.groupby(["rater_id", "system"])[col].mean().unstack("system")
    meta = out.drop_duplicates("system").set_index("system")
    for sys_name, row in meta.iterrows():
        base = f"hindi-standard-{row['speaker']}"
        if row["mode"] == "standard" or base not in per_rater:
            continue
        pair = per_rater[[base, sys_name]].dropna()
        if len(pair) >= 2:
            prefs.append({"system": sys_name, "baseline": base,
                          **paired_comparison(pair[base], pair[sys_name])})
    extra = {k: v for k, v in vars(norm).items() if k.endswith("_") and not k.startswith("_")
             and k in ("offsets_", "dialect_effects_", "backend_used_")}
    if hasattr(norm, "fits_"):
        extra["regression_fits"] = {d: vars(f) for d, f in norm.fits_.items()}
    return _jsonable({"n_ratings": int(len(df)), "correction": correction, "weighting": weighting,
                      "systems": systems.to_dict("records"), "by_dialect": by_dialect.to_dict("records"),
                      "preferences": prefs, "model": extra})


def _jsonable(obj):
    """NaN/inf -> None, numpy scalars -> Python (strict JSON for the API)."""
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, np.generic):
        obj = obj.item()
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    return obj
