"""Synthetic listening-test data with *known* ground truth.

Used by the tests (can each correction recover a planted dialect bias?) and by
``scripts/power_analysis.py`` (how many raters per dialect does a study need?).
"""
from __future__ import annotations

from typing import Mapping

import numpy as np
import pandas as pd


def simulate_ratings(
    system_quality: Mapping[str, float],
    dialect_bias: Mapping[str, float],
    raters_per_dialect: int = 10,
    n_sentences: int = 20,
    rater_sd: float = 0.3,
    sentence_sd: float = 0.2,
    noise_sd: float = 0.4,
    step: float = 0.5,
    seed: int = 0,
) -> pd.DataFrame:
    """Every rater scores every (system, sentence); scores rounded to ``step`` in [1, 5]."""
    rng = np.random.default_rng(seed)
    sent_eff = rng.normal(0, sentence_sd, n_sentences)
    rows = []
    for dialect, bias in dialect_bias.items():
        for r in range(raters_per_dialect):
            rid = f"{dialect}_{r:02d}"
            lenient = rng.normal(0, rater_sd)
            for system, q in system_quality.items():
                for s in range(n_sentences):
                    raw = q + bias + lenient + sent_eff[s] + rng.normal(0, noise_sd)
                    score = float(np.clip(np.round(raw / step) * step, 1, 5))
                    rows.append({"rater_id": rid, "rater_dialect": dialect, "system": system,
                                 "sentence_id": s, "score": score})
    return pd.DataFrame(rows)
