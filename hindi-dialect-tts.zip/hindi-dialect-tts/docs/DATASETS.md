# Datasets to plug in

Check each licence before redistribution. Sizes and coverage are approximate; confirm them on
the dataset page.

## 1. Synthesis: voices and dialect speech

| dataset | what it gives this project | use |
|---|---|---|
| **AI4Bharat Indic-TTS checkpoints** (GitHub releases, `hi.zip`) | Hindi FastPitch + HiFi-GAN, male and female | default engine (`scripts/download_indic_tts.py`) |
| **IndicTTS database** (IIT Madras) | studio Hindi male/female recordings the AI4Bharat models were trained on | natural references for DMOS, fine-tuning |
| **SYSPIN corpus** (IISc SPIRE Lab; LIMMITS challenges) | TTS-grade single-speaker data in Hindi plus Chhattisgarhi, Bhojpuri, Magahi, Maithili | real dialect voices to compare with rule-based rendering; natural Chhattisgarhi references |
| **IndicVoices-R** (AI4Bharat) | multi-speaker TTS data with speaker district metadata | dialect-conditioned / multi-speaker voices |
| **Rasa** (AI4Bharat) | expressive Indic TTS data | prosody/style experiments |

## 2. Evaluation: listeners, accents, objective checks

| dataset | what it gives this project | use |
|---|---|---|
| **Lahaja** (AI4Bharat) | Hindi speech from speakers in many districts (multi-accent ASR benchmark) | accent-robust ASR to score intelligibility (WER/CER) of synthetic speech per dialect |
| **Vaani** (IISc + ARTPARK + Google) | district-wise spontaneous speech across India | evidence of real dialect pronunciations; mining lexicon candidates |
| **IndicVoices** (AI4Bharat) | large read and spontaneous speech with demographic metadata | same as above, plus ASR training |

## 3. Lexicons and text

| source | use |
|---|---|
| Paper Table 4 (in `data/lexicon/*.csv`, `source=paper_table4`) | seed rules + lexicon |
| Chhattisgarhi dictionary (SCERT Chhattisgarh), Haryanvi–Hindi dictionary (cited by the paper, refs 30–31) | grow the lexicons to the paper's ~1,500 / ~2,100 entries |
| Native-speaker review of `community_seed` rows | set `verified=yes` |
| IndicCorp / Sangraha Hindi text | pick sentences with high coverage of the dialect patterns |

## 4. Format for your own data

Ratings collected elsewhere (Excel score sheets, Google Forms, the paper's evaluation pages)
→ CSV:

```
rater_id,rater_dialect,system,sentence_id,score,test_type,native_place,state
HR-01,haryanvi,hindi-standard-female,1,4,MOS,Rohtak,Haryana
```

```bash
python scripts/manage.py import-ratings my_scores.csv
python scripts/manage.py results --correction mixed --weighting equal
```

Lexicon additions → append rows to `data/lexicon/<dialect>.csv`
(`hindi,dialect_form,pos,source,verified,notes`), then `python scripts/manage.py init`
(adds new rows only).
