# Replication plan

Target paper: B. Gupta (MeitY), *Evaluating user preferences in Hindi Text-to-Speech*.

**Claims to test**

* C1. Evaluators' scores for the same Hindi TTS output vary with their native dialect.
* C2. Speech rendered with dialect patterns gets higher scores than standard Hindi:
  character variations > word variations > standard (Table 5).
* C3. A per-dialect linear mapping to Khadi Boli scores (Sec. 6.1) makes grading uniform.

The work runs in three stages, from cheapest to most informative.

## Stage A – computational reproduction (done, no new data)

`python scripts/replicate_paper.py` → `reports/replication_report.md`

| check | result |
|---|---|
| Table-5 condition means | reproduced exactly (3.87/4.22/4.08 and 3.85/4.12/4.06) |
| C2 significance (paired Wilcoxon, Holm-corrected) | all 4 dialect-vs-standard differences p < 0.05, Δ = +0.21 to +0.35 |
| Sec. 6.1 coefficients vs printed predictions | consistent to 5×10⁻⁷; held-out inputs recovered on the 0.5 grid |
| Predictive value of the Sec. 6.1 regression | none: slopes ≈ 0, test MAE ≥ predicting the mean (n_test = 4) |
| Figures 3/4 vs coefficients | inconsistent: plotted lines/visible points have slope ≈ 0.21–0.25 |

Missing for a full reproduction: per-sentence raw scores, evaluators' native dialects,
the 20 sentences, audio, the 5 TTS systems' identities, the ~1,500/2,100-word dictionaries.
Ask the author / TDIL for these first; if they arrive, load them with
`scripts/manage.py import-ratings` and rerun every analysis.

## Stage B – conceptual replication (new listening test)

**Stimuli**

* 20 sentences from `data/sentences_hi.csv`, which cover every Table-4 pattern; add 20
  neutral sentences with no dialect triggers as a control.
* Systems per voice (female + male, AI4Bharat Indic-TTS):
  `hindi-standard`, `{haryanvi,chhattisgarhi}-char`, `{haryanvi,chhattisgarhi}-lexicon`
  (= paper conditions), plus `combined` as our extension.
* Natural recordings of all sentences by one Khadi Boli speaker for DMOS
  (upload via `/admin/natural/{id}`).

**Listeners** – the key change from the paper

* Three groups recruited by native place: Khadi Boli (reference: western UP/Delhi),
  Haryanvi (Haryana districts), Chhattisgarhi (Chhattisgarh districts).
* ≥ 20 per group. Under the simulator's default variances, `scripts/power_analysis.py`
  gives power ≈ 0.87 for a 0.15-MOS paired effect with 10 raters and 20 sentences, and 5
  raters can never reach p < 0.05 with the exact Wilcoxon test. Rerun it with your pilot variances. Wester et al. (2015) also argue for more listeners than
  typical TTS evaluations use.
* Record metadata in the app (native place, state, age, education, gender).

**Procedure**

* Blind, randomised order (the app never shows system names), headphones, short training on
  anchor samples.
* MOS (ACR 1–5) for all stimuli; DMOS (DCR) against the natural reference.
* Every listener hears every system on a balanced Latin-square subset of sentences, so system
  and dialect effects can be told apart.
* Include 2–3 repeated items for intra-rater consistency, and exclude listeners whose
  repeated-item scores differ by ≥ 2.

**Pre-registered analysis** (all in the app)

1. C1: `mixed` model `score ~ system + rater_dialect + (1|rater)`; test the dialect fixed
   effect (likelihood-ratio test). Report variance components.
2. C2: add `system × rater_dialect`. The prediction is that dialect conditions gain more
   from matching-dialect listeners than from Khadi Boli listeners. Paired Wilcoxon per group
   on per-rater means with Holm correction (`/results` → `preferences`).
3. C3: compare `none`, `paper_regression`, `offset`, `zscore`, `mixed` by (a) between-dialect
   spread left after correction, (b) stability of system rankings under leave-one-group-out,
   (c) agreement with the reference group on held-out sentences.
4. Report MOS ± 95 % CI with `weighting=equal` and `weighting=population`.

**Success criteria**: C1 replicates if the dialect effect is significant with |effect| ≥ 0.1
MOS. C2 replicates if the dialect conditions beat standard for matching-dialect listeners.
C3 replicates if `paper_regression` lowers the between-dialect spread without reordering systems.

## Stage C – extensions

* Objective checks next to MOS: Hindi ASR WER/CER on the synthetic audio (e.g. AI4Bharat
  IndicConformer) and UTMOS-style predicted MOS, compared across dialect modes.
* Grow the lexicons from the published Chhattisgarhi/Haryanvi dictionaries and native-speaker
  review, then measure how rule coverage and rule precision affect MOS.
* Train or fine-tune voices on real dialect speech (SYSPIN Chhattisgarhi, Vaani, IndicVoices; see
  DATASETS.md) and compare them with rule-based dialect rendering.
