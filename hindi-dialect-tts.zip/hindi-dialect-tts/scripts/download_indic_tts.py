#!/usr/bin/env python3
"""Download AI4Bharat Indic-TTS Hindi checkpoints and fix config paths.

    python scripts/download_indic_tts.py                 # -> models/indic-tts/hi
    python scripts/download_indic_tts.py --lang hi --out models/indic-tts

The released configs contain absolute paths from the training machine for the
speaker file; this script rewrites them to the local ``speakers.pth``.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

RELEASE = "https://github.com/AI4Bharat/Indic-TTS/releases/download/v1-checkpoints-release/{lang}.zip"


def patch_config(cfg_path: Path, speakers: Path) -> None:
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    changed = False

    def fix(d: dict) -> None:
        nonlocal changed
        for key in ("speakers_file", "speaker_file", "d_vector_file"):
            if key in d and d[key]:
                d[key] = str(speakers)
                changed = True
    fix(cfg)
    if isinstance(cfg.get("model_args"), dict):
        fix(cfg["model_args"])
    if changed:
        cfg_path.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"patched speaker path in {cfg_path}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--lang", default="hi")
    ap.add_argument("--out", default="models/indic-tts")
    ap.add_argument("--zip", help="use an already-downloaded zip instead of fetching")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    zpath = Path(a.zip) if a.zip else out / f"{a.lang}.zip"
    if not zpath.exists():
        url = RELEASE.format(lang=a.lang)
        print(f"downloading {url} (several hundred MB)…")
        with urllib.request.urlopen(url) as r, open(zpath, "wb") as fh:
            shutil.copyfileobj(r, fh)
    with zipfile.ZipFile(zpath) as z:
        for m in z.namelist():                      # guard against path traversal
            if Path(m).is_absolute() or ".." in Path(m).parts:
                raise SystemExit(f"unsafe path in zip: {m}")
        z.extractall(out)
    root = out / a.lang
    speakers = (root / "fastpitch" / "speakers.pth").resolve()
    if not speakers.exists():
        print(f"warning: {speakers} not found – check the archive layout", file=sys.stderr)
    for cfg in (root / "fastpitch" / "config.json", root / "hifigan" / "config.json"):
        if cfg.exists():
            patch_config(cfg, speakers)
    print(f"done. set INDIC_TTS_MODEL_DIR={out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
