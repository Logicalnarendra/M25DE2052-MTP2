#!/usr/bin/env python3
"""Database / data management CLI.

    python scripts/manage.py init                    # create tables + seed dialects, lexicon, sentences, systems
    python scripts/manage.py generate                # synthesise all sentence × system samples
    python scripts/manage.py import-ratings FILE.csv # bulk-load ratings collected elsewhere (e.g. paper sheets)
    python scripts/manage.py export-ratings out.csv
    python scripts/manage.py results --correction mixed --weighting equal

import-ratings CSV columns:
    rater_id, rater_dialect, system, sentence_id, score[, test_type][, native_place, state]
(systems and evaluators are created on the fly; audio paths are left empty)
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402
from sqlalchemy import select  # noqa: E402

from app import services  # noqa: E402
from app.config import get_settings  # noqa: E402
from app.db import Database  # noqa: E402
from app.models import AudioSample, Evaluator, Rating, Sentence, TTSSystem  # noqa: E402
from app.tts import get_engine  # noqa: E402


def cmd_init(db, s, a):
    print(services.seed_all(db, s.tts_engine, tuple(a.speakers.split(","))))


def cmd_generate(db, s, a):
    print({"generated": services.generate_samples(db, get_engine(s.tts_engine), s.audio_dir, s.rule_level)})


def cmd_import(db, s, a):
    df = pd.read_csv(a.file).fillna("")          # blank optional cells -> "" (not "nan")
    services.seed_dialects(db)
    n = 0
    for row in df.itertuples(index=False):
        r = row._asdict()
        ev = db.scalar(select(Evaluator).where(Evaluator.code == str(r["rater_id"])))
        if ev is None:
            ev = Evaluator(code=str(r["rater_id"]), dialect_id=services.dialect_by_code(db, r["rater_dialect"]).id,
                           native_place=str(r.get("native_place", "") or ""), state=str(r.get("state", "") or ""))
            db.add(ev)
            db.flush()
        sysrow = db.scalar(select(TTSSystem).where(TTSSystem.name == str(r["system"])))
        if sysrow is None:
            sysrow = TTSSystem(name=str(r["system"]), engine="imported",
                               mode=str(r.get("mode", "standard") or "standard"))
            db.add(sysrow)
            db.flush()
        sid = int(r["sentence_id"])
        if db.get(Sentence, sid) is None:
            db.add(Sentence(id=sid, text_hi=f"(imported sentence {sid})"))
            db.flush()
        sample = db.scalar(select(AudioSample).where(AudioSample.sentence_id == sid,
                                                     AudioSample.system_id == sysrow.id))
        if sample is None:
            sample = AudioSample(sentence_id=sid, system_id=sysrow.id, path="")
            db.add(sample)
            db.flush()
        db.add(Rating(evaluator_id=ev.id, sample_id=sample.id,
                      test_type=str(r.get("test_type", "MOS") or "MOS"), score=float(r["score"])))
        n += 1
    db.commit()
    print({"imported": n})


def cmd_export(db, s, a):
    services.ratings_frame(db, a.test_type).to_csv(a.file, index=False)
    print(f"wrote {a.file}")


def cmd_results(db, s, a):
    df = services.ratings_frame(db, a.test_type)
    print(json.dumps(services.compute_results(df, a.correction, a.weighting, s.reference_dialect),
                     indent=2, ensure_ascii=False))


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init"); p.add_argument("--speakers", default="female"); p.set_defaults(fn=cmd_init)
    p = sub.add_parser("generate"); p.set_defaults(fn=cmd_generate)
    p = sub.add_parser("import-ratings"); p.add_argument("file"); p.set_defaults(fn=cmd_import)
    p = sub.add_parser("export-ratings"); p.add_argument("file"); p.add_argument("--test-type", default="MOS")
    p.set_defaults(fn=cmd_export)
    p = sub.add_parser("results"); p.add_argument("--test-type", default="MOS")
    p.add_argument("--correction", default="none"); p.add_argument("--weighting", default="none")
    p.set_defaults(fn=cmd_results)
    a = ap.parse_args()
    s = get_settings()
    database = Database(s.database_url)
    database.create_all()
    with database.SessionLocal() as db:
        a.fn(db, s, a)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
