#!/usr/bin/env python3
"""Reproduce the analyses of Gupta, "Evaluating user preferences in Hindi TTS".

    python scripts/replicate_paper.py            # writes reports/replication_report.md + PNGs

Stage A (this script, no audio needed) re-derives every number that can be
checked from the published tables. Stage B/C (new listening test) are
described in docs/REPLICATION.md.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

from app.evaluation.report import compute_results  # noqa: E402
from app.evaluation.simulate import simulate_ratings  # noqa: E402
from app.replication.paper import (PUBLISHED_REGRESSIONS, check_published_regression,  # noqa: E402
                                   digitized_points, refit_digitized, table5_means,
                                   table5_preferences)

OUT = ROOT / "reports"


def fig_table5(path: Path) -> None:
    m = table5_means()
    order = ["standard", "char", "lexicon"]
    labels = {"standard": "Hindi TTS", "char": "Character variations", "lexicon": "Word variations (dictionary)"}
    fig, ax = plt.subplots(figsize=(7, 3.6))
    width = 0.26
    for i, cond in enumerate(order):
        sub = m[m.condition == cond].set_index("dialect_sheet").loc[["chhattisgarhi", "haryanvi"]]
        err = 1.96 * sub["std"] / np.sqrt(sub["count"])
        ax.bar(np.arange(2) + (i - 1) * width, sub["mean"], width, yerr=err, capsize=3, label=labels[cond])
    ax.set_xticks(range(2), ["Chhattisgarhi sheet", "Haryanvi sheet"])
    ax.set_ylim(3.5, 4.6)
    ax.set_ylabel("Mean grade (1–5)")
    ax.legend(frameon=False, fontsize=8, loc="upper left")
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def fig_regression(path: Path) -> None:
    pts = digitized_points()
    fig, axes = plt.subplots(1, 2, figsize=(8, 3.4), sharey=True)
    for ax, d in zip(axes, ["bundeli", "haryanvi"]):
        g = pts[pts.dialect == d]
        reg = PUBLISHED_REGRESSIONS[d]
        xs = np.linspace(2, 4.5, 50)
        a, b = np.polyfit(g.x_dialect_score, g.y_khadiboli_score, 1)
        ax.scatter(g.x_dialect_score, g.y_khadiboli_score, s=18, label="visible points (digitised)")
        ax.plot(xs, reg.coef * xs + reg.intercept, label=f"published: y={reg.coef:.3f}x+{reg.intercept:.2f}")
        ax.plot(xs, a * xs + b, ls="--", label=f"refit visible: y={a:.3f}x+{b:.2f}")
        ax.set_title(d.capitalize())
        ax.set_xlabel(f"{d} grade")
        ax.spines[["top", "right"]].set_visible(False)
        ax.legend(frameon=False, fontsize=7, loc="lower right")
    axes[0].set_ylabel("Khadi Boli grade")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def correction_benchmark() -> str:
    """Planted-bias benchmark: which correction recovers the true system gap?"""
    truth = {"hindi-standard-female": 3.6, "haryanvi-char-female": 3.9}
    bias = {"khadiboli": 0.0, "haryanvi": 0.5, "chhattisgarhi": 0.3}
    rows = ["| correction | overall gap (true 0.30) | abs error | gap inside Haryanvi raters (true 0.30) "
            "| between-dialect spread left |",
            "|---|---|---|---|---|"]
    errs: dict[str, list[float]] = {}
    spreads: dict[str, list[float]] = {}
    within: dict[str, list[float]] = {}
    for seed in range(20):
        df = simulate_ratings(truth, bias, raters_per_dialect=10, n_sentences=20, seed=seed)
        # unbalanced design: dialect raters hear mostly the dialect system
        drop = (df.rater_dialect != "khadiboli") & (df.system == "hindi-standard-female") & (df.sentence_id >= 5)
        df = df[~drop].copy()
        df["mode"] = np.where(df.system.str.contains("standard"), "standard", "char")
        df["speaker"] = "female"
        for c in ["none", "paper_regression", "offset", "zscore", "mixed"]:
            r = compute_results(df, c)
            m = {s["system"]: s["mean"] for s in r["systems"]}
            gap = m["haryanvi-char-female"] - m["hindi-standard-female"]
            errs.setdefault(c, []).append(gap)
            bd = [x["mean"] for x in r["by_dialect"] if x["system"] == "haryanvi-char-female"]
            spreads.setdefault(c, []).append(max(bd) - min(bd))
            hd = {x["system"]: x["mean"] for x in r["by_dialect"] if x["rater_dialect"] == "haryanvi"}
            within.setdefault(c, []).append(hd["haryanvi-char-female"] - hd["hindi-standard-female"])
    for c, gaps in errs.items():
        g = float(np.mean(gaps))
        rows.append(f"| `{c}` | {g:.3f} | {abs(g - 0.30):.3f} | {np.mean(within[c]):.3f} | "
                    f"{np.mean(spreads[c]):.3f} |")
    return "\n".join(rows)


def main() -> int:
    OUT.mkdir(exist_ok=True)
    fig_table5(OUT / "table5_means.png")
    fig_regression(OUT / "regression_check.png")

    means = table5_means()
    prefs = table5_preferences()
    checks = [check_published_regression(r) for r in PUBLISHED_REGRESSIONS.values()]
    refit = refit_digitized()

    md = ["# Replication report – Evaluating user preferences in Hindi TTS", "",
          "Generated by `scripts/replicate_paper.py`.", "",
          "## A1. Table 5 – mean grade per condition", "",
          "| dialect sheet | condition | mean | sd | n |", "|---|---|---|---|---|"]
    for r in means.itertuples():
        md.append(f"| {r.dialect_sheet} | {r.condition} | {r.mean:.2f} | {r.std:.3f} | {r.count} |")
    md += ["", "![Table 5](table5_means.png)", "",
           "## A2. Paired tests vs. standard Hindi TTS (same 10 evaluators)", "",
           "| sheet | condition | Δ mean | 95% CI | Cohen dz | Wilcoxon p | Holm p | % evaluators preferring |",
           "|---|---|---|---|---|---|---|---|"]
    for r in prefs.itertuples():
        md.append(f"| {r.dialect_sheet} | {r.treatment.split('_', 1)[1]} | {r.mean_diff:+.2f} | "
                  f"[{r.ci_low:.2f}, {r.ci_high:.2f}] | {r.cohens_dz:.2f} | {r.wilcoxon_p:.4f} | "
                  f"{r.wilcoxon_p_holm:.4f} | {100 * r.frac_prefer_treatment:.0f}% |")
    md += ["", "## A3. Regression normalisation (Sec. 6.1)", "",
           "| dialect | recovered held-out x | coefficients reproduce predictions | test MAE | MAE of predicting the mean |",
           "|---|---|---|---|---|"]
    for c in checks:
        md.append(f"| {c['dialect']} | {c['recovered_x']} | {'yes' if c['consistent'] else 'NO'} "
                  f"(max err {c['max_abs_error']:.1e}) | {c['test_mae']:.3f} | {c['mean_predictor_mae']:.3f} |")
    md += ["", "| dialect | visible pts | slope (refit of plotted points) | published slope |", "|---|---|---|---|"]
    for r in refit.itertuples():
        md.append(f"| {r.dialect} | {r.n_visible_points} | {r.slope_digitized:.3f} | {r.slope_published:.3f} |")
    md += ["", "![Regression check](regression_check.png)", "",
           "## A4. Correction methods on a planted-bias benchmark", "",
           "20 simulated studies; Haryanvi raters +0.5 and Chhattisgarhi raters +0.3 more lenient than Khadi Boli raters; dialect raters hear "
           "the standard system on only 5 of 20 sentences (unbalanced, as in real deployments).", "",
           correction_benchmark(), "",
           "## Findings", "",
           "1. **Table 5 reproduces**: means 3.87/4.22/4.08 (Chhattisgarhi sheet) and 3.85/4.12/4.06 "
           "(Haryanvi sheet). Both dialect-aware conditions beat standard Hindi; all four paired "
           "differences survive Holm correction, with large effect sizes – but n = 10 evaluators.",
           "2. **Regression coefficients are internally consistent** with the printed test predictions "
           "(held-out inputs land exactly on the 0.5 grade grid).",
           "3. **…but the normalisation has no predictive value**: slopes are ≈ 0 (−0.012, 0.076), so every "
           "dialect score is mapped to ≈ 4.7 regardless of input; test MAE is no better than predicting "
           "the mean, and with 4 test items no conclusion is possible.",
           "4. **Figures and coefficients disagree**: the lines drawn in Figs 3/4 (and an OLS fit of the "
           "visible points, slope ≈ 0.21–0.25) are much steeper than the reported coefficients – the "
           "figure was probably fitted on all items and the coefficients on the 80 % split.",
           "5. **Design gap**: Table 5 does not say which evaluators are native speakers of which "
           "dialect, so dialect preference and dialect *rater bias* are confounded. Separating them "
           "needs reference-dialect and target-dialect raters scoring the same stimuli (Stage B).",
           "6. **Benchmark (A4)**: with enough shared items the paper's regression does remove the group "
           "offset, but because its slope is < 1 it also shrinks real quality differences seen *within* a "
           "dialect group. `offset` and `mixed` remove the bias without compressing the scale; `mixed` "
           "additionally handles raters who did not hear every system and gives rater-level effects, so "
           "it is the recommended default. Raw (`none`) scores overstate the system gap by ~50 %.", ""]
    (OUT / "replication_report.md").write_text("\n".join(md), encoding="utf-8")
    print(f"wrote {OUT / 'replication_report.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
