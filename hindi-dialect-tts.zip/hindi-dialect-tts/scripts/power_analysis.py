#!/usr/bin/env python3
"""How many raters per dialect are needed to detect a given MOS difference?

    python scripts/power_analysis.py --effect 0.2 --raters 5 10 20 30 --sims 200

Simulates paired designs (every rater hears both systems) with realistic
rater/sentence/noise variance and reports the share of simulated studies in
which the Wilcoxon test on per-rater means reaches p < alpha.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402

from app.evaluation.simulate import simulate_ratings  # noqa: E402
from app.evaluation.stats import paired_comparison  # noqa: E402


def power(effect: float, raters: int, sentences: int, sims: int, alpha: float) -> float:
    hits = 0
    for seed in range(sims):
        df = simulate_ratings({"base": 3.8, "dialect": 3.8 + effect}, {"haryanvi": 0.0},
                              raters_per_dialect=raters, n_sentences=sentences, seed=seed)
        per = df.groupby(["rater_id", "system"])["score"].mean().unstack()
        hits += paired_comparison(per["base"], per["dialect"])["wilcoxon_p"] < alpha
    return hits / sims


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--effect", type=float, default=0.2)
    ap.add_argument("--raters", type=int, nargs="+", default=[5, 10, 20, 30])
    ap.add_argument("--sentences", type=int, default=20)
    ap.add_argument("--sims", type=int, default=200)
    ap.add_argument("--alpha", type=float, default=0.05)
    a = ap.parse_args()
    print(f"effect={a.effect} MOS, sentences={a.sentences}, alpha={a.alpha}")
    for r in a.raters:
        print(f"  raters/dialect={r:3d}  power={power(a.effect, r, a.sentences, a.sims, a.alpha):.2f}")
    return 0


if __name__ == "__main__":
    np.seterr(all="ignore")
    raise SystemExit(main())
