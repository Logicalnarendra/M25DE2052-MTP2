"""End-to-end API flow on SQLite + mock engine.

Needs the web/DB dependencies (pip install -r requirements.txt)."""
import pytest

pytest.importorskip("fastapi")
pytest.importorskip("sqlalchemy")
pytest.importorskip("httpx")

from urllib.parse import unquote  # noqa: E402

from fastapi.testclient import TestClient  # noqa: E402

from app.config import Settings  # noqa: E402
from app.main import create_app  # noqa: E402
from app.tts import MockTTSEngine, to_wav_bytes  # noqa: E402


@pytest.fixture
def client(tmp_path):
    s = Settings(database_url=f"sqlite:///{tmp_path / 'test.db'}", tts_engine="mock",
                 audio_dir=tmp_path / "audio", admin_token="secret")
    with TestClient(create_app(s, MockTTSEngine())) as c:
        yield c


ADMIN = {"X-Admin-Token": "secret"}


def test_health_and_dialects(client):
    assert client.get("/health").json()["status"] == "ok"
    codes = {d["code"] for d in client.get("/dialects").json()}
    assert {"khadiboli", "haryanvi", "chhattisgarhi"} <= codes


def test_transform(client):
    r = client.post("/transform", json={"text": "राजा ने अपने हाथ से खाना खाया।", "dialect": "haryanvi"})
    assert r.status_code == 200
    body = r.json()
    assert "हात" in body["text"] and body["ssml"].startswith("<?xml")
    assert client.post("/transform", json={"text": "x", "dialect": "klingon"}).status_code == 422


def test_synthesize_wav_and_ssml(client):
    r = client.post("/synthesize", json={"text": "सीता आए", "dialect": "chhattisgarhi"})
    assert r.status_code == 200 and r.content[:4] == b"RIFF"
    assert unquote(r.headers["x-rendered-text"]) == "छीता आये"
    bad = client.post("/synthesize", json={"text": "x", "ssml": "<speak><unclosed></speak>"})
    assert bad.status_code == 422


def test_pls(client):
    r = client.get("/lexicon/haryanvi.pls")
    assert r.status_code == 200 and "<lexeme>" in r.text


def test_admin_requires_token(client):
    assert client.post("/admin/seed").status_code == 401


def test_full_listening_test_flow(client):
    assert client.post("/admin/seed", headers=ADMIN).json()["systems"] == 5
    assert client.post("/admin/generate", headers=ADMIN).json()["generated"] == 100   # 20 sentences x 5

    ids = {}
    for code, dialect in [("K1", "khadiboli"), ("K2", "khadiboli"), ("H1", "haryanvi"), ("H2", "haryanvi")]:
        r = client.post("/evaluators", json={"code": code, "dialect": dialect, "state": "HR"})
        assert r.status_code == 201
        ids[code] = r.json()["id"]
    assert client.post("/evaluators", json={"code": "K1", "dialect": "khadiboli"}).status_code == 409

    # each evaluator rates 30 random samples; Haryanvi raters are more lenient
    for code, eid in ids.items():
        for _ in range(30):
            nxt = client.get("/test/next", params={"evaluator_id": eid}).json()
            assert "system" not in nxt and nxt["audio_url"].startswith("/audio/")   # blind
            assert client.get(nxt["audio_url"]).content[:4] == b"RIFF"
            score = 5 if code.startswith("H") else 3
            assert client.post("/ratings", json={"evaluator_id": eid, "sample_id": nxt["sample_id"],
                                                 "score": score}).status_code == 201
    again = {"evaluator_id": eid, "sample_id": nxt["sample_id"], "score": 4}     # last one rated above
    assert client.post("/ratings", json=again).status_code == 409
    assert client.post("/ratings", json={**again, "score": 7}).status_code == 422

    raw = client.get("/results").json()
    assert raw["n_ratings"] >= 120
    fixed = client.get("/results", params={"correction": "offset", "weighting": "equal"}).json()
    by_d = {(x["system"], x["rater_dialect"]): x["mean"] for x in fixed["by_dialect"]}
    assert all(abs(v - 3) < 0.6 for v in by_d.values())     # leniency removed
    assert client.get("/results/ratings.csv").text.startswith("rater_id")


def test_dmos_needs_natural_reference(client):
    client.post("/admin/seed", headers=ADMIN)
    client.post("/admin/generate", headers=ADMIN)
    eid = client.post("/evaluators", json={"code": "D1", "dialect": "khadiboli"}).json()["id"]
    assert client.get("/test/next", params={"evaluator_id": eid, "test_type": "DMOS"}).json() is None
    wav = to_wav_bytes(MockTTSEngine().synthesize("प्राकृतिक"), 16000)
    up = client.post("/admin/natural/1", headers=ADMIN, files={"file": ("n.wav", wav, "audio/wav")})
    assert up.status_code == 200
    nxt = client.get("/test/next", params={"evaluator_id": eid, "test_type": "DMOS"}).json()
    assert nxt["reference_url"] == f"/audio/{up.json()['sample_id']}"
