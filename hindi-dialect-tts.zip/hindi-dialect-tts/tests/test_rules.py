"""Every pattern example from paper Table 4 must be reproduced by its rule."""
import pytest

from app.dialects.devanagari import geminate, nfc
from app.dialects.rules import DIALECTS, RULES, rules_for

CASES = [(r.id, src, tgt) for r in RULES for src, tgt in r.examples]


@pytest.mark.parametrize("rule_id,src,tgt", CASES, ids=[f"{c[0]}:{c[1]}" for c in CASES])
def test_rule_reproduces_paper_example(rule_id, src, tgt):
    rule = next(r for r in RULES if r.id == rule_id)
    assert rule.apply(nfc(src)) == nfc(tgt)


def test_every_rule_has_examples_and_known_dialect():
    for r in RULES:
        assert r.examples, r.id
        assert r.dialect in DIALECTS


def test_rule_ids_unique():
    ids = [r.id for r in RULES]
    assert len(ids) == len(set(ids))


def test_levels_are_nested():
    for d in DIALECTS:
        cons = {r.id for r in rules_for(d, "conservative")}
        full = {r.id for r in rules_for(d, "full")}
        assert cons <= full


def test_unknown_dialect_and_level():
    with pytest.raises(KeyError):
        rules_for("klingon")
    with pytest.raises(ValueError):
        rules_for("haryanvi", "extreme")


@pytest.mark.parametrize("c,expected", [("ज", "ज्ज"), ("ख", "क्ख"), ("भ", "ब्भ"), (nfc("ड़"), "ड्ड")])
def test_geminate(c, expected):
    assert geminate(c) == expected


def _apply_all(dialect, level, word):
    w = nfc(word)
    for r in rules_for(dialect, level):
        w = r.apply(w)
    return w


def test_haryanvi_na_after_virama_is_kept():
    assert _apply_all("haryanvi", "conservative", "स्नान").startswith("स्न")


@pytest.mark.parametrize("word", ["खाया", "ज़रूर", "क्या", "घर"])
def test_haryanvi_conservative_leaves_unaffected_words(word):
    assert _apply_all("haryanvi", "conservative", word) == nfc(word)


def test_nukta_letters_other_than_rra_not_geminated():
    assert _apply_all("khadiboli", "full", "राज़ी") == nfc("राज़ी")
