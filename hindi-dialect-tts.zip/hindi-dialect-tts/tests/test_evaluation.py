import numpy as np
import pandas as pd
import pytest
from scipy import stats

from app.evaluation import get_normalizer, mos_table, paired_comparison, summarize, validate_ratings
from app.evaluation.bias import MixedEffectsNormalizer, PaperRegressionNormalizer
from app.evaluation.report import compute_results
from app.evaluation.simulate import simulate_ratings
from app.evaluation.stats import holm
from app.evaluation.weights import (equal_weights, inverse_variance_weights, population_weights,
                                    weighted_mos)

BIAS = {"khadiboli": 0.0, "haryanvi": 0.5, "chhattisgarhi": -0.4}
SYSTEMS = {"hindi-standard-female": 3.4, "haryanvi-char-female": 3.7}


@pytest.fixture(scope="module")
def df():
    d = simulate_ratings(SYSTEMS, BIAS, raters_per_dialect=10, n_sentences=20, seed=3)
    d["mode"] = np.where(d.system.str.contains("standard"), "standard", "char")
    d["speaker"] = "female"
    return d


# ---------------------------------------------------------------- MOS
def test_summarize_matches_scipy():
    x = [3, 4, 4, 5, 2, 4, 3]
    s = summarize(x)
    lo, hi = stats.t.interval(0.95, len(x) - 1, loc=np.mean(x), scale=stats.sem(x))
    assert s.mean == pytest.approx(np.mean(x))
    assert (s.ci_low, s.ci_high) == pytest.approx((lo, hi))


def test_summarize_edge_cases():
    assert summarize([]).n == 0
    one = summarize([4])
    assert one.ci_low == one.ci_high == 4


def test_validate_ratings_range(df):
    bad = df.copy()
    bad.loc[0, "score"] = 6
    with pytest.raises(ValueError):
        validate_ratings(bad)
    with pytest.raises(ValueError):
        validate_ratings(df.drop(columns="rater_dialect"))


def test_mos_table_shape(df):
    t = mos_table(df, ("system", "rater_dialect"))
    assert len(t) == 6 and (t.n == 200).all()


# ---------------------------------------------------------------- corrections
@pytest.mark.parametrize("name", ["offset", "mixed", "zscore", "paper_regression"])
def test_corrections_remove_dialect_gap(df, name):
    raw_spread = np.ptp(df.groupby("rater_dialect").score.mean())
    out = get_normalizer(name).fit_transform(df)
    spread = np.ptp(out.groupby("rater_dialect").score_corrected.mean())
    assert raw_spread > 0.6
    assert spread < 0.1


@pytest.mark.parametrize("name", ["offset", "mixed"])
def test_bias_estimates_recover_planted_values(df, name):
    norm = get_normalizer(name).fit(df)
    est = norm.offsets_ if name == "offset" else norm.dialect_effects_
    sign = -1 if name == "offset" else 1           # offset = amount added to fix the bias
    for d, b in BIAS.items():
        assert sign * est[d] == pytest.approx(b, abs=0.15)


def test_mixed_numpy_matches_offset_on_balanced_design(df):
    m = MixedEffectsNormalizer(backend="numpy").fit(df)
    o = get_normalizer("offset").fit(df)
    for d in BIAS:
        assert m.dialect_effects_[d] == pytest.approx(-o.offsets_[d], abs=1e-6)
    assert m.var_rater_ > 0 and m.var_resid_ > 0


def test_mixed_handles_unbalanced_design(df):
    sub = df[~((df.rater_dialect == "haryanvi") & (df.system == "hindi-standard-female") & (df.sentence_id > 3))]
    m = MixedEffectsNormalizer(backend="numpy").fit(sub)
    assert m.dialect_effects_["haryanvi"] == pytest.approx(0.5, abs=0.15)


def test_corrections_preserve_system_ranking(df):
    for name in ["none", "offset", "zscore", "mixed", "paper_regression"]:
        out = get_normalizer(name).fit_transform(df)
        m = out.groupby("system").score_corrected.mean()
        assert m["haryanvi-char-female"] > m["hindi-standard-female"]


def test_paper_regression_recovers_exact_line():
    rows = []
    for s in range(10):
        x = 2 + 0.25 * s
        rows += [{"rater_id": "k", "rater_dialect": "khadiboli", "system": "A", "sentence_id": s, "score": 0.5 * x + 2},
                 {"rater_id": "h", "rater_dialect": "haryanvi", "system": "A", "sentence_id": s, "score": x}]
    f = PaperRegressionNormalizer(test_size=None).fit(pd.DataFrame(rows)).fits_["haryanvi"]
    assert (f.coef, f.intercept) == pytest.approx((0.5, 2.0))


def test_requires_reference_raters(df):
    with pytest.raises(ValueError):
        get_normalizer("offset").fit(df[df.rater_dialect != "khadiboli"])


def test_unknown_correction():
    with pytest.raises(ValueError):
        get_normalizer("magic")


def test_transform_before_fit(df):
    with pytest.raises(RuntimeError):
        get_normalizer("offset").transform(df)


# ---------------------------------------------------------------- weights
def test_weights_sum_to_one(df):
    for w in (equal_weights(["a", "b", "c"]), population_weights(["haryanvi", "khadiboli"]),
              inverse_variance_weights(df)):
        assert sum(w.values()) == pytest.approx(1.0)
    with pytest.raises(KeyError):
        population_weights(["klingon"])


def test_equal_weighting_ignores_headcount(df):
    extra = df[df.rater_dialect == "haryanvi"].copy()
    extra["rater_id"] += "_dup"
    skewed = pd.concat([df, extra])                 # haryanvi now has 2x raters
    w = equal_weights(skewed.rater_dialect.unique())
    a = weighted_mos(df, w).set_index("system").weighted_mos
    b = weighted_mos(skewed, w).set_index("system").weighted_mos
    assert np.allclose(a, b)


# ---------------------------------------------------------------- stats
def test_paired_comparison_basic():
    r = paired_comparison([3, 3, 4, 3, 4, 3, 3, 4], [4, 4, 4, 4, 5, 4, 4, 5])
    assert r["mean_diff"] == pytest.approx(0.875)
    assert r["wilcoxon_p"] < 0.05 and r["frac_prefer_treatment"] == pytest.approx(7 / 8)


def test_holm():
    assert holm([0.01, 0.04, 0.03]) == pytest.approx([0.03, 0.06, 0.06])


# ---------------------------------------------------------------- report
@pytest.mark.parametrize("corr", ["none", "paper_regression", "offset", "zscore", "mixed"])
@pytest.mark.parametrize("wt", ["none", "equal", "population", "inverse_var"])
def test_compute_results_is_strict_json(df, corr, wt):
    import json
    r = compute_results(df, corr, wt)
    json.dumps(r, allow_nan=False)
    assert r["preferences"] and r["preferences"][0]["baseline"] == "hindi-standard-female"


def test_compute_results_empty():
    assert compute_results(pd.DataFrame())["n_ratings"] == 0
