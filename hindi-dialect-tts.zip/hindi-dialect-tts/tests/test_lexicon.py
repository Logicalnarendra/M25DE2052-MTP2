import pytest

from app.dialects.devanagari import nfc
from app.dialects.lexicon import Lexicon, LexiconEntry


@pytest.fixture(scope="module")
def lex():
    return Lexicon.from_dir()


def test_loads_all_seed_dialects(lex):
    assert {"haryanvi", "chhattisgarhi", "awadhi", "brajbhasha", "bihari", "khadiboli"} <= set(lex.dialects())
    assert len(lex) > 100


@pytest.mark.parametrize("dialect,hindi,form", [
    ("haryanvi", "अठारह", "ठारा"), ("haryanvi", "पीना", "पीवणा"),
    ("chhattisgarhi", "कचहरी", "कछेरी"), ("awadhi", "स्कूल", "इस्कूल"), ("bihari", "रात", "ड़ात"),
])
def test_paper_entries_present(lex, dialect, hindi, form):
    e = lex.lookup(dialect, hindi)
    assert e is not None and e.dialect_form == nfc(form)


def test_lookup_is_nfc_insensitive(lex):
    decomposed = "गाड़ी"       # गाड़ी written with separate nukta
    assert lex.lookup("haryanvi", decomposed).dialect_form == nfc("गाड्डी")


def test_paper_entries_verified_community_not(lex):
    assert all(e.verified for e in lex.entries() if e.source == "paper_table4")
    assert not any(e.verified for e in lex.entries() if e.source == "community_seed")


def test_verified_only_filter():
    v = Lexicon.from_dir(verified_only=True)
    assert all(e.verified for e in v.entries())


def test_rejects_bad_entries():
    lex = Lexicon()
    with pytest.raises(KeyError):
        lex.add(LexiconEntry("klingon", "a", "b"))
    with pytest.raises(ValueError):
        lex.add(LexiconEntry("haryanvi", " ", "b"))
