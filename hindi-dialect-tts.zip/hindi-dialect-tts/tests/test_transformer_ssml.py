import xml.etree.ElementTree as ET

import pytest

from app.dialects import DialectTransformer, Lexicon, flatten_ssml, to_pls, to_ssml
from app.dialects.ssml import PLS_NS, SSML_NS


@pytest.fixture(scope="module")
def lex():
    return Lexicon.from_dir()


SENT = "राजा ने अपने हाथ से खाना खाया। क्या तुम आओगे?"


def test_standard_is_identity(lex):
    r = DialectTransformer("haryanvi", lex).transform(SENT, "standard")
    assert r.text == r.original and r.changes == []


def test_char_mode_uses_rules_only(lex):
    r = DialectTransformer("haryanvi", lex, "full").transform(SENT, "char")
    assert "राज्जा" in r.text and "अपणे" in r.text and "हात" in r.text
    assert "क्या" in r.text                       # function word only in the dictionary
    assert all(c.origin.startswith("rule:") for c in r.changes)


def test_lexicon_mode_uses_dictionary_only(lex):
    r = DialectTransformer("haryanvi", lex).transform(SENT, "lexicon")
    assert "के तुम" in r.text
    assert all(c.origin == "lexicon" for c in r.changes)


def test_combined_falls_back_to_rules_for_oov(lex):
    r = DialectTransformer("haryanvi", lex, "full").transform("उसका दोस्त शिक्षक है", "combined")
    assert "सिक्सक" in r.text
    assert any(c.origin.startswith("rule:") for c in r.changes)


def test_punctuation_and_spacing_preserved(lex):
    r = DialectTransformer("chhattisgarhi", lex).transform("  सीता,  आए! 123 ", "combined")
    assert r.text == "  छीता,  आये! 123 "


def test_change_offsets_point_into_original(lex):
    r = DialectTransformer("haryanvi", lex).transform(SENT, "combined")
    for c in r.changes:
        assert r.original[c.start:c.end] == c.source


def test_invalid_mode(lex):
    with pytest.raises(ValueError):
        DialectTransformer("haryanvi", lex).transform("x", "fancy")


def test_ssml_is_valid_and_uses_sub(lex):
    r = DialectTransformer("haryanvi", lex).transform(SENT, "combined")
    ssml = to_ssml(r, rate="90%", voice="hi-female", lexicon_uri="/lexicon/haryanvi.pls")
    root = ET.fromstring(ssml.encode())
    assert root.tag == f"{{{SSML_NS}}}speak"
    subs = root.findall(f".//{{{SSML_NS}}}sub")
    assert len(subs) == r.n_changed
    assert {s.text for s in subs} == {c.source for c in r.changes}
    assert {s.get("alias") for s in subs} == {c.target for c in r.changes}


def test_ssml_escapes_markup(lex):
    r = DialectTransformer("haryanvi", lex).transform("<b>हाथ</b> & साथ", "combined")
    ET.fromstring(to_ssml(r).encode())            # must not raise


def test_flatten_roundtrip_speaks_dialect_forms(lex):
    r = DialectTransformer("chhattisgarhi", lex).transform("सीता कचहरी गई। फिर घर आए।", "combined")
    segs = flatten_ssml(to_ssml(r, sentence_break_ms=250))
    texts = [s.text for s in segs if s.text]
    assert texts == ["छीता कछेरी गई।", "फिर घर आये।"]
    assert [s.pause_ms for s in segs if s.pause_ms] == [250]


def test_flatten_prosody_and_breaks():
    ssml = (f'<speak version="1.1" xmlns="{SSML_NS}">एक <break time="1.5s"/>'
            '<prosody rate="slow">दो <sub alias="तीण">तीन</sub></prosody><break strength="weak"/>चार</speak>')
    segs = flatten_ssml(ssml)
    assert segs[0].text == "एक" and segs[1].pause_ms == 1500
    assert segs[2].text == "दो तीण" and segs[2].rate == 0.75
    assert segs[3].pause_ms == 200 and segs[4].text == "चार"


def test_flatten_rejects_entities():
    with pytest.raises(ValueError):
        flatten_ssml('<!DOCTYPE x [<!ENTITY a "b">]><speak>&a;</speak>')


def test_pls_valid(lex):
    root = ET.fromstring(to_pls(lex, "awadhi").encode())
    lexemes = root.findall(f"{{{PLS_NS}}}lexeme")
    assert len(lexemes) == len(lex.entries("awadhi"))
    first = lexemes[0]
    assert first.find(f"{{{PLS_NS}}}grapheme").text and first.find(f"{{{PLS_NS}}}alias").text


def test_flatten_malformed_ssml_raises_valueerror():
    with pytest.raises(ValueError, match="malformed"):
        flatten_ssml("<speak><unclosed></speak>")
