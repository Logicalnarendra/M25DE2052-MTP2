"""Stage-A replication: numbers published in the paper."""
import pytest

from app.replication.paper import (PUBLISHED_REGRESSIONS, check_published_regression, refit_digitized,
                                   table5, table5_means, table5_preferences)


def test_table5_shape():
    t = table5()
    assert t.shape == (10, 7)
    assert t.iloc[:, 1:].stack().between(1, 5).all()


@pytest.mark.parametrize("sheet,cond,mean", [
    ("chhattisgarhi", "standard", 3.87), ("chhattisgarhi", "char", 4.22), ("chhattisgarhi", "lexicon", 4.08),
    ("haryanvi", "standard", 3.85), ("haryanvi", "char", 4.12), ("haryanvi", "lexicon", 4.06),
])
def test_table5_condition_means(sheet, cond, mean):
    m = table5_means().set_index(["dialect_sheet", "condition"])
    assert m.loc[(sheet, cond), "mean"] == pytest.approx(mean, abs=1e-9)


def test_dialect_conditions_preferred_significantly():
    p = table5_preferences()
    assert (p.mean_diff > 0).all()
    assert (p.wilcoxon_p_holm < 0.05).all()


@pytest.mark.parametrize("dialect", list(PUBLISHED_REGRESSIONS))
def test_published_coefficients_reproduce_published_predictions(dialect):
    c = check_published_regression(PUBLISHED_REGRESSIONS[dialect])
    assert c["consistent"]
    assert all(2 <= x <= 5 for x in c["recovered_x"])


def test_published_regression_not_better_than_mean():
    for reg in PUBLISHED_REGRESSIONS.values():
        c = check_published_regression(reg)
        assert c["test_mae"] >= c["mean_predictor_mae"] - 1e-9


def test_plotted_points_steeper_than_reported_slope():
    r = refit_digitized()
    assert (r.slope_digitized > r.slope_published + 0.1).all()
