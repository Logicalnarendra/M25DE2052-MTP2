import numpy as np
import pytest

from app.dialects import DialectTransformer, Lexicon, to_ssml
from app.tts import MockTTSEngine, TTSError, get_engine, read_wav, to_wav_bytes, write_wav
from app.tts.indic_tts import IndicTTSEngine


@pytest.fixture
def eng():
    return MockTTSEngine()


def test_registry_returns_mock():
    assert get_engine("mock").name == "mock"
    with pytest.raises(TTSError):
        get_engine("nope")


def test_mock_is_deterministic_and_text_sensitive(eng):
    a = eng.synthesize("हाथ")
    assert np.array_equal(a, eng.synthesize("हाथ"))
    assert not np.array_equal(a, eng.synthesize("हात"))


def test_rate_changes_duration(eng):
    assert len(eng.synthesize("नमस्ते", rate=2.0)) < len(eng.synthesize("नमस्ते"))


def test_unknown_speaker(eng):
    with pytest.raises(TTSError):
        eng.synthesize("x", speaker="robot")


def test_ssml_synthesis_adds_pauses(eng):
    r = DialectTransformer("haryanvi", Lexicon.from_dir()).transform("राजा आया। हाथ धोओ।", "combined")
    with_break = eng.synthesize_ssml(to_ssml(r, sentence_break_ms=500))
    no_break = eng.synthesize_ssml(to_ssml(r, sentence_break_ms=None))
    assert len(with_break) - len(no_break) == pytest.approx(0.5 * eng.sample_rate, abs=eng.sample_rate * 0.05)


def test_wav_roundtrip(tmp_path, eng):
    audio = eng.synthesize("परीक्षण")
    p = write_wav(tmp_path / "x" / "a.wav", audio, eng.sample_rate)
    back, sr = read_wav(p)
    assert sr == eng.sample_rate and len(back) == len(audio)
    assert np.max(np.abs(back - audio)) < 1e-3
    assert to_wav_bytes(audio, sr)[:4] == b"RIFF"


def test_indic_tts_reports_missing_checkpoints(tmp_path):
    e = IndicTTSEngine(tmp_path)
    assert len(e.missing_files()) == 5
    with pytest.raises(TTSError, match="download_indic_tts"):
        e.synthesize("नमस्ते")


@pytest.mark.indic
def test_indic_tts_real_model():
    """Runs only with `pytest -m indic` after downloading checkpoints."""
    import os
    e = IndicTTSEngine(os.getenv("INDIC_TTS_MODEL_DIR", "models/indic-tts"))
    if e.missing_files():
        pytest.skip("Indic-TTS checkpoints not downloaded")
    pytest.importorskip("TTS")
    audio = e.synthesize("नमस्ते, आप कैसे हैं?", speaker="female")
    assert audio.size > e.sample_rate * 0.5 and np.isfinite(audio).all()
