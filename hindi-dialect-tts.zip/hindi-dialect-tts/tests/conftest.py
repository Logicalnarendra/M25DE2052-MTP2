import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# Never touch real models or the dev database from tests.
os.environ["TTS_ENGINE"] = "mock"
os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")
