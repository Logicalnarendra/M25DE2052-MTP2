# MTP Hindi Dialect TTS Dataset (v1.0)

Dataset for the project *Dialect-Aware Synthesis and Bias-Corrected Evaluation for Hindi
Text-to-Speech Systems*, built to the MTP-1 methodology. Upload the zip to the Colab toolkit
(`Hindi_Dialect_TTS_Colab_MTP.ipynb`, section 2b).

## Description (MTP-1 table)

| Item | MTP-1 | This dataset |
|---|---|---|
| Evaluators | 10 | 2 per listener group × 5 groups (Khadi Boli reference + 4 target dialects); 5 M / 5 F |
| Sentences | 20 | 5 per target dialect, 6 speaking styles |
| Dialects | 4+ | Haryanvi, Chhattisgarhi, Bundeli, Braj Bhasha + Khadi Boli (reference) |
| Voices | Male/Female | 10 male / 10 female sentences |
| TTS models | 5 | M1–M5 (`models/tts_models.csv`) |
| Stimuli | – | 100 = 20 sentences × 5 models |
| Ratings planned | – | 2,000 (MOS + DMOS) + 4 repeats per evaluator and test |
| Multidialect corpus (planned) | – | 400 utterances = 5 dialects × 2 speakers (M/F) × 40 prompts |

## Objectives → files

| Objective | Files |
|---|---|
| 1 Dialect-aware TTS framework | `models/tts_models.csv`, `lexicon/`, `lexicon/pls/` |
| 2 Balanced multi-dialect dataset | `sentences/`, `evaluators/`, `corpus/` (prompts, recording plan) |
| 3 Phonology and prosody variation | `features/` (phonetic inventory, category profile, lexical substitutions, prosody profiles) |
| 4 Dialect embedding in neural TTS | `corpus/manifest_PLANNED.csv` (training data layout, dialect labels) |
| 5 Bias correction of MOS/DMOS | `stimuli/` (100 stimuli, blinded rating sheets, key), `ratings/` |
| 6 Experimental analysis | `ratings/ratings_TEMPLATE.csv`, `reference_study/` (published numbers for comparison) |

## Folders

```
sentences/eval_sentences.csv         20 sentences: target dialect, voice, style, dialect rendering, IPA, changes
lexicon/<dialect>.csv                Hindi → dialect dictionary (source, verified flag) ; pls/ = W3C PLS export
evaluators/evaluator_panel.csv       10 evaluator slots (fill native place, state, age, education)
models/tts_models.csv                M1–M5 and the Colab engine each one uses
stimuli/stimuli.csv                  100 stimuli (sentence × model) with blinded codes
stimuli/rating_sheets/E01_MOS.csv …  one MOS and one DMOS sheet per evaluator (randomised, blinded)
stimuli/playlists_KEY_researcher_only.csv   code ↔ model key (do not give to evaluators)
features/                            phonetic / lexical / prosodic feature tables
corpus/recording_prompts.csv         40 prompts × 5 dialects (20 read, 12 conversational, 8 expressive)
corpus/manifest_PLANNED.csv          400 planned recordings: utt_id, path, text, dialect, speaker, gender, style
corpus/natural_references_PLANNED.csv  20 natural recordings needed for DMOS / MCD
ratings/ratings_TEMPLATE.csv         format of the final ratings table
ratings/ratings_SIMULATED_demo_DO_NOT_REPORT.csv   simulated ratings with planted bias – for testing only
reference_study/                     Table 5 and regression numbers of the reference paper
```

## What still has to be collected

1. **Corpus recordings** – record the 400 planned utterances (`corpus/manifest_PLANNED.csv`) with native
   speakers; speakers read the Hindi prompt and say it naturally in their dialect (the dialect spelling
   column is only a hint). Chhattisgarhi and Khadi Boli can be complemented with public corpora (SYSPIN,
   IndicTTS) – check licences.
2. **Natural references** – 20 recordings `REF_01.wav … REF_20.wav` (`corpus/natural_references_PLANNED.csv`).
3. **Ratings** – the 10 evaluators fill in their two sheets.
4. **Lexicon verification** – rows with `verified = no` must be confirmed by two native speakers.

The simulated ratings file exists only to test the evaluation code; never report its numbers.
